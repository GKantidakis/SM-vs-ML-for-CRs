


load("results_csc.RData")
load("results_fg.RData")
load("results_keras_relu_patience3.RData")
load("results_nnet.RData")
load("results_rsf_logrank.RData")
library(ggplot2)

# function that calculates the quantiles and the mean

summa <- function(x) {
  
  res1 <- round(quantile(x, probs = c(0, 0.025, 0.5, 0.975, 1), na.rm = TRUE), digits = 3)
  res2 <- round(mean(x, na.rm = TRUE), digits = 3)
  res3 <- round(sd(x, na.rm = TRUE), digits = 3)
  res <- c(res1[1:3], res2, res1[4:5], res3)
  names(res) <- c("Min.", "2.5% Qu.", "Median", "Mean", "97.5% Qu.", "Max.", "Sd.")
  return(res)
}



quant_low <- function(x) {
  res <- as.numeric(quantile(x, probs = 0.025, na.rm = TRUE))
  return(res)
}

quant_high <- function(x) {
  res <- as.numeric(quantile(x, probs = 0.975, na.rm = TRUE))
  return(res)
}



##########################################
# For cause-specific Cox model
##########################################

# cause 1
brier_csc_cause1 <- matrix(data = 0, nrow = length(list_csc), ncol = 16) # Brier score until 15 years
auc_csc_cause1 <- matrix(data = 0, nrow = length(list_csc), ncol = 16) # AUC until 15 years
calib_csc5y_cause1 <- vector(mode = "numeric", length = length(list_csc))
calib_csc10y_cause1 <- vector(mode = "numeric", length = length(list_csc))
calib_csc15y_cause1 <- vector(mode = "numeric", length = length(list_csc))

# cause 2
brier_csc_cause2 <- matrix(data = 0, nrow = length(list_csc), ncol = 16) # Brier score until 15 years
auc_csc_cause2 <- matrix(data = 0, nrow = length(list_csc), ncol = 16) # AUC until 15 years
calib_csc5y_cause2 <- vector(mode = "numeric", length = length(list_csc))
calib_csc10y_cause2 <- vector(mode = "numeric", length = length(list_csc))
calib_csc15y_cause2 <- vector(mode = "numeric", length = length(list_csc))


for (i in 1:length(list_csc)){
  
  
  brier_csc_cause1[i, ] <- list_csc[[i]]$Brier_cause1[1:16]
  brier_csc_cause2[i, ] <- list_csc[[i]]$Brier_cause2[1:16]
  auc_csc_cause1[i, ] <- list_csc[[i]]$AUC_cause1[1:16]
  auc_csc_cause2[i, ] <- list_csc[[i]]$AUC_cause2[1:16]
  
  calib_csc5y_cause1[i] <- list_csc[[i]]$MSE5_cause1
  calib_csc5y_cause2[i] <- list_csc[[i]]$MSE5_cause2
  calib_csc10y_cause1[i] <- list_csc[[i]]$MSE10_cause1
  calib_csc10y_cause2[i] <- list_csc[[i]]$MSE10_cause2 
  calib_csc15y_cause1[i] <- list_csc[[i]]$MSE15_cause1
  calib_csc15y_cause2[i] <- list_csc[[i]]$MSE15_cause2
  
}




##########################################
# For Fine-Gray model
##########################################


# cause 1
brier_fg_cause1 <- matrix(data = 0, nrow = length(list_fg), ncol = 16) # Brier score until 15 years
auc_fg_cause1 <- matrix(data = 0, nrow = length(list_fg), ncol = 16) # AUC until 15 years
calib_fg5y_cause1 <- vector(mode = "numeric", length = length(list_fg))
calib_fg10y_cause1 <- vector(mode = "numeric", length = length(list_fg))
calib_fg15y_cause1 <- vector(mode = "numeric", length = length(list_fg))

# cause 2
brier_fg_cause2 <- matrix(data = 0, nrow = length(list_fg), ncol = 16) # Brier score until 15 years
auc_fg_cause2 <- matrix(data = 0, nrow = length(list_fg), ncol = 16) # AUC until 15 years
calib_fg5y_cause2 <- vector(mode = "numeric", length = length(list_fg))
calib_fg10y_cause2 <- vector(mode = "numeric", length = length(list_fg))
calib_fg15y_cause2 <- vector(mode = "numeric", length = length(list_fg))


for (i in 1:length(list_fg)){
  
  
  brier_fg_cause1[i, ] <- list_fg[[i]]$Brier_cause1[1:16]
  brier_fg_cause2[i, ] <- list_fg[[i]]$Brier_cause2[1:16]
  auc_fg_cause1[i, ] <- list_fg[[i]]$AUC_cause1[1:16]
  auc_fg_cause2[i, ] <- list_fg[[i]]$AUC_cause2[1:16]
  
  calib_fg5y_cause1[i] <- list_fg[[i]]$MSE5_cause1
  calib_fg5y_cause2[i] <- list_fg[[i]]$MSE5_cause2
  calib_fg10y_cause1[i] <- list_fg[[i]]$MSE10_cause1
  calib_fg10y_cause2[i] <- list_fg[[i]]$MSE10_cause2 
  calib_fg15y_cause1[i] <- list_fg[[i]]$MSE15_cause1
  calib_fg15y_cause2[i] <- list_fg[[i]]$MSE15_cause2
  
}




##########################################
# For PLANNCR original
##########################################


# cause 1
brier_nnet_cause1 <- matrix(data = 0, nrow = length(list_nnet), ncol = 16) # Brier score until 15 years
auc_nnet_cause1 <- matrix(data = 0, nrow = length(list_nnet), ncol = 16) # AUC until 15 years
calib_nnet5y_cause1 <- vector(mode = "numeric", length = length(list_nnet))
calib_nnet10y_cause1 <- vector(mode = "numeric", length = length(list_nnet))
calib_nnet15y_cause1 <- vector(mode = "numeric", length = length(list_nnet))

# cause 2
brier_nnet_cause2 <- matrix(data = 0, nrow = length(list_nnet), ncol = 16) # Brier score until 15 years
auc_nnet_cause2 <- matrix(data = 0, nrow = length(list_nnet), ncol = 16) # AUC until 15 years
calib_nnet5y_cause2 <- vector(mode = "numeric", length = length(list_nnet))
calib_nnet10y_cause2 <- vector(mode = "numeric", length = length(list_nnet))
calib_nnet15y_cause2 <- vector(mode = "numeric", length = length(list_nnet))


for (i in 1:length(list_nnet)){
  
  
  brier_nnet_cause1[i, ] <- list_nnet[[i]]$Brier_cause1[1:16]
  brier_nnet_cause2[i, ] <- list_nnet[[i]]$Brier_cause2[1:16]
  auc_nnet_cause1[i, ] <- list_nnet[[i]]$AUC_cause1[1:16]
  auc_nnet_cause2[i, ] <- list_nnet[[i]]$AUC_cause2[1:16]
  
  calib_nnet5y_cause1[i] <- list_nnet[[i]]$MSE5_cause1
  calib_nnet5y_cause2[i] <- list_nnet[[i]]$MSE5_cause2
  calib_nnet10y_cause1[i] <- list_nnet[[i]]$MSE10_cause1
  calib_nnet10y_cause2[i] <- list_nnet[[i]]$MSE10_cause2 
  calib_nnet15y_cause1[i] <- list_nnet[[i]]$MSE15_cause1
  calib_nnet15y_cause2[i] <- list_nnet[[i]]$MSE15_cause2
  
}


##########################################
# For PLANNCR extended
##########################################

# cause 1
brier_keras_cause1 <- matrix(data = 0, nrow = length(list_keras), ncol = 16) # Brier score until 15 years
auc_keras_cause1 <- matrix(data = 0, nrow = length(list_keras), ncol = 16) # AUC until 15 years
calib_keras5y_cause1 <- vector(mode = "numeric", length = length(list_keras))
calib_keras10y_cause1 <- vector(mode = "numeric", length = length(list_keras))
calib_keras15y_cause1 <- vector(mode = "numeric", length = length(list_keras))

# cause 2
brier_keras_cause2 <- matrix(data = 0, nrow = length(list_keras), ncol = 16) # Brier score until 15 years
auc_keras_cause2 <- matrix(data = 0, nrow = length(list_keras), ncol = 16) # AUC until 15 years
calib_keras5y_cause2 <- vector(mode = "numeric", length = length(list_keras))
calib_keras10y_cause2 <- vector(mode = "numeric", length = length(list_keras))
calib_keras15y_cause2 <- vector(mode = "numeric", length = length(list_keras))


for (i in 1:length(list_keras)){
  
  
  brier_keras_cause1[i, ] <- list_keras[[i]]$Brier_cause1[1:16]
  brier_keras_cause2[i, ] <- list_keras[[i]]$Brier_cause2[1:16]
  auc_keras_cause1[i, ] <- list_keras[[i]]$AUC_cause1[1:16]
  auc_keras_cause2[i, ] <- list_keras[[i]]$AUC_cause2[1:16]
  
  calib_keras5y_cause1[i] <- list_keras[[i]]$MSE5_cause1
  calib_keras5y_cause2[i] <- list_keras[[i]]$MSE5_cause2
  calib_keras10y_cause1[i] <- list_keras[[i]]$MSE10_cause1
  calib_keras10y_cause2[i] <- list_keras[[i]]$MSE10_cause2 
  calib_keras15y_cause1[i] <- list_keras[[i]]$MSE15_cause1
  calib_keras15y_cause2[i] <- list_keras[[i]]$MSE15_cause2
  
}



##########################################
# For RSFCR
##########################################

# cause 1
brier_rsf_cause1 <- matrix(data = 0, nrow = length(list_rsf), ncol = 16) # Brier score until 15 years
auc_rsf_cause1 <- matrix(data = 0, nrow = length(list_rsf), ncol = 16) # AUC until 15 years
calib_rsf5y_cause1 <- vector(mode = "numeric", length = length(list_rsf))
calib_rsf10y_cause1 <- vector(mode = "numeric", length = length(list_rsf))
calib_rsf15y_cause1 <- vector(mode = "numeric", length = length(list_rsf))

# cause 2
brier_rsf_cause2 <- matrix(data = 0, nrow = length(list_rsf), ncol = 16) # Brier score until 15 years
auc_rsf_cause2 <- matrix(data = 0, nrow = length(list_rsf), ncol = 16) # AUC until 15 years
calib_rsf5y_cause2 <- vector(mode = "numeric", length = length(list_rsf))
calib_rsf10y_cause2 <- vector(mode = "numeric", length = length(list_rsf))
calib_rsf15y_cause2 <- vector(mode = "numeric", length = length(list_rsf))


for (i in 1:length(list_rsf)){
  
  
  brier_rsf_cause1[i, ] <- list_rsf[[i]]$Brier_cause1[1:16]
  brier_rsf_cause2[i, ] <- list_rsf[[i]]$Brier_cause2[1:16]
  auc_rsf_cause1[i, ] <- list_rsf[[i]]$AUC_cause1[1:16]
  auc_rsf_cause2[i, ] <- list_rsf[[i]]$AUC_cause2[1:16]
  
  calib_rsf5y_cause1[i] <- list_rsf[[i]]$MSE5_cause1
  calib_rsf5y_cause2[i] <- list_rsf[[i]]$MSE5_cause2
  calib_rsf10y_cause1[i] <- list_rsf[[i]]$MSE10_cause1
  calib_rsf10y_cause2[i] <- list_rsf[[i]]$MSE10_cause2 
  calib_rsf15y_cause1[i] <- list_rsf[[i]]$MSE15_cause1
  calib_rsf15y_cause2[i] <- list_rsf[[i]]$MSE15_cause2
  
}


# Boxplots for miscalibration (for the event of interest: disease relapse)

# at 5 years

df1 <- data.frame(Calib_groups = calib_csc5y_cause1,
                  Model = "Cause-specific Cox",
                  Time = "5 years")


df2 <- data.frame(Calib_groups = calib_fg5y_cause1,
                  Model = "Fine-Gray",
                  Time = "5 years")

df3 <- data.frame(Calib_groups = calib_nnet5y_cause1,
                  Model = "PLANNCR original",
                  Time = "5 years")


df4 <- data.frame(Calib_groups = calib_keras5y_cause1,
                  Model = "PLANNCR extended",
                  Time = "5 years")

df5 <- data.frame(Calib_groups = calib_rsf5y_cause1,
                  Model = "RSFCR",
                  Time = "5 years")


#at 10 years

df6 <- data.frame(Calib_groups = calib_csc10y_cause1,
                  Model = "Cause-specific Cox",
                  Time = "10 years")


df7 <- data.frame(Calib_groups = calib_fg10y_cause1,
                  Model = "Fine-Gray",
                  Time = "10 years")

df8 <- data.frame(Calib_groups = calib_nnet10y_cause1,
                  Model = "PLANNCR original",
                  Time = "10 years")


df9 <- data.frame(Calib_groups = calib_keras10y_cause1,
                  Model = "PLANNCR extended",
                  Time = "10 years")

df10 <- data.frame(Calib_groups = calib_rsf10y_cause1,
                  Model = "RSFCR",
                  Time = "10 years")

#at 15 years

df11 <- data.frame(Calib_groups = calib_csc15y_cause1,
                  Model = "Cause-specific Cox",
                  Time = "15 years")


df12 <- data.frame(Calib_groups = calib_fg15y_cause1,
                  Model = "Fine-Gray",
                  Time = "15 years")

df13 <- data.frame(Calib_groups = calib_nnet15y_cause1,
                  Model = "PLANNCR original",
                  Time = "15 years")


df14 <- data.frame(Calib_groups = calib_keras15y_cause1,
                  Model = "PLANNCR extended",
                  Time = "15 years")

df15 <- data.frame(Calib_groups = calib_rsf15y_cause1,
                   Model = "RSFCR",
                   Time = "15 years")


dfa <- rbind(df1, df2, df3, df4, df5, df6, df7, df8,
            df9, df10, df11, df12, df13, df14, df15)

dfa$Model <- as.factor(dfa$Model)
dfa$Model <- factor(dfa$Model, levels = c("Cause-specific Cox", "Fine-Gray", "PLANNCR original",
                                        "PLANNCR extended", "RSFCR"))
dfa$Time <- as.factor(dfa$Time)
dfa$Time <- factor(dfa$Time, levels = c("5 years", "10 years", "15 years"))


calib_c1 <- ggplot(dfa, aes(x=Time, y=Calib_groups, fill = Model)) + 
  geom_boxplot(notch = FALSE) +
  scale_fill_brewer(palette="PuBu") +  
  ylim(c(0, 0.03)) + 
  labs(title = " ",x = "Time",
       y = "Miscalibration (for disease relapse)", fill = " ") +
  theme(axis.text.x = element_text(face="bold", color="#993333", 
                                   size=11)) +
  theme(legend.position = "top", 
        plot.title = element_text(hjust = 0.5)) # Remove legend by setting to "none" 

calib_c1


# Boxplots for miscalibration (for the competing event death)

# at 5 years

df16 <- data.frame(Calib_groups = calib_csc5y_cause2,
                  Model = "Cause-specific Cox",
                  Time = "5 years")


df17 <- data.frame(Calib_groups = calib_fg5y_cause2,
                  Model = "Fine-Gray",
                  Time = "5 years")

df18 <- data.frame(Calib_groups = calib_nnet5y_cause2,
                  Model = "PLANNCR original",
                  Time = "5 years")


df19 <- data.frame(Calib_groups = calib_keras5y_cause2,
                  Model = "PLANNCR extended",
                  Time = "5 years")

df20 <- data.frame(Calib_groups = calib_rsf5y_cause2,
                  Model = "RSFCR",
                  Time = "5 years")


#at 10 years

df21 <- data.frame(Calib_groups = calib_csc10y_cause2,
                  Model = "Cause-specific Cox",
                  Time = "10 years")


df22 <- data.frame(Calib_groups = calib_fg10y_cause2,
                  Model = "Fine-Gray",
                  Time = "10 years")

df23 <- data.frame(Calib_groups = calib_nnet10y_cause2,
                  Model = "PLANNCR original",
                  Time = "10 years")


df24 <- data.frame(Calib_groups = calib_keras10y_cause2,
                  Model = "PLANNCR extended",
                  Time = "10 years")

df25 <- data.frame(Calib_groups = calib_rsf10y_cause2,
                   Model = "RSFCR",
                   Time = "10 years")

#at 15 years

df26 <- data.frame(Calib_groups = calib_csc15y_cause2,
                   Model = "Cause-specific Cox",
                   Time = "15 years")


df27 <- data.frame(Calib_groups = calib_fg15y_cause2,
                   Model = "Fine-Gray",
                   Time = "15 years")

df28 <- data.frame(Calib_groups = calib_nnet15y_cause2,
                   Model = "PLANNCR original",
                   Time = "15 years")


df29 <- data.frame(Calib_groups = calib_keras15y_cause2,
                   Model = "PLANNCR extended",
                   Time = "15 years")

df30 <- data.frame(Calib_groups = calib_rsf15y_cause2,
                   Model = "RSFCR",
                   Time = "15 years")


dfb <- rbind(df16, df17, df18, df19, df20, df21, df22, df23,
            df24, df25, df26, df27, df28, df29, df30)

dfb$Model <- as.factor(dfb$Model)
dfb$Model <- factor(dfb$Model, levels = c("Cause-specific Cox", "Fine-Gray", "PLANNCR original",
                                        "PLANNCR extended", "RSFCR"))
dfb$Time <- as.factor(dfb$Time)
dfb$Time <- factor(dfb$Time, levels = c("5 years", "10 years", "15 years"))




calib_c2 <- ggplot(dfb, aes(x=Time, y=Calib_groups, fill = Model)) + 
  geom_boxplot(notch = FALSE) +
  scale_fill_brewer(palette="OrRd") +  
  ylim(c(0, 0.03)) + 
  labs(title = " ",x = "Time",
       y = "Miscalibration (for death)", fill = " ") +
  theme(axis.text.x = element_text(face="bold", color="#993333", 
                                   size=11)) +
  theme(legend.position = "top", 
        plot.title = element_text(hjust = 0.5)) # Remove legend by setting to "none" 


calib_c2





