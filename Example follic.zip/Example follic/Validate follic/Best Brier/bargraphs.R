
load("results_csc.RData")
load("results_fg.RData")
load("results_keras_relu_patience3.RData")
load("results_nnet.RData")
load("results_rsf_logrank.RData")
library(ggplot2)

# function that calculates the quantiles and the mean

summa <- function(x) {
  
  res1 <- round(quantile(x, probs = c(0, 0.025, 0.5, 0.975, 1), na.rm = TRUE), digits = 3)
  res2 <- round(mean(x, na.rm = TRUE), digits = 3)
  res3 <- round(sd(x, na.rm = TRUE), digits = 3)
  res <- c(res1[1:3], res2, res1[4:5], res3)
  names(res) <- c("Min.", "2.5% Qu.", "Median", "Mean", "97.5% Qu.", "Max.", "Sd.")
  return(res)
}



quant_low <- function(x) {
  res <- as.numeric(quantile(x, probs = 0.025, na.rm = TRUE))
  return(res)
}

quant_high <- function(x) {
  res <- as.numeric(quantile(x, probs = 0.975, na.rm = TRUE))
  return(res)
}



##########################################
# For cause-specific Cox model
##########################################

# cause 1
brier_csc_cause1 <- matrix(data = 0, nrow = length(list_csc), ncol = 16) # Brier score until 15 years
auc_csc_cause1 <- matrix(data = 0, nrow = length(list_csc), ncol = 16) # AUC until 15 years
calib_csc5y_cause1 <- vector(mode = "numeric", length = length(list_csc))
calib_csc10y_cause1 <- vector(mode = "numeric", length = length(list_csc))
calib_csc15y_cause1 <- vector(mode = "numeric", length = length(list_csc))

# cause 2
brier_csc_cause2 <- matrix(data = 0, nrow = length(list_csc), ncol = 16) # Brier score until 15 years
auc_csc_cause2 <- matrix(data = 0, nrow = length(list_csc), ncol = 16) # AUC until 15 years
calib_csc5y_cause2 <- vector(mode = "numeric", length = length(list_csc))
calib_csc10y_cause2 <- vector(mode = "numeric", length = length(list_csc))
calib_csc15y_cause2 <- vector(mode = "numeric", length = length(list_csc))


for (i in 1:length(list_csc)){
  
  
  brier_csc_cause1[i, ] <- list_csc[[i]]$Brier_cause1[1:16]
  brier_csc_cause2[i, ] <- list_csc[[i]]$Brier_cause2[1:16]
  auc_csc_cause1[i, ] <- list_csc[[i]]$AUC_cause1[1:16]
  auc_csc_cause2[i, ] <- list_csc[[i]]$AUC_cause2[1:16]
  
  calib_csc5y_cause1[i] <- list_csc[[i]]$MSE5_cause1
  calib_csc5y_cause2[i] <- list_csc[[i]]$MSE5_cause2
  calib_csc10y_cause1[i] <- list_csc[[i]]$MSE10_cause1
  calib_csc10y_cause2[i] <- list_csc[[i]]$MSE10_cause2 
  calib_csc15y_cause1[i] <- list_csc[[i]]$MSE15_cause1
  calib_csc15y_cause2[i] <- list_csc[[i]]$MSE15_cause2
  
}




##########################################
# For Fine-Gray model
##########################################


# cause 1
brier_fg_cause1 <- matrix(data = 0, nrow = length(list_fg), ncol = 16) # Brier score until 15 years
auc_fg_cause1 <- matrix(data = 0, nrow = length(list_fg), ncol = 16) # AUC until 15 years
calib_fg5y_cause1 <- vector(mode = "numeric", length = length(list_fg))
calib_fg10y_cause1 <- vector(mode = "numeric", length = length(list_fg))
calib_fg15y_cause1 <- vector(mode = "numeric", length = length(list_fg))

# cause 2
brier_fg_cause2 <- matrix(data = 0, nrow = length(list_fg), ncol = 16) # Brier score until 15 years
auc_fg_cause2 <- matrix(data = 0, nrow = length(list_fg), ncol = 16) # AUC until 15 years
calib_fg5y_cause2 <- vector(mode = "numeric", length = length(list_fg))
calib_fg10y_cause2 <- vector(mode = "numeric", length = length(list_fg))
calib_fg15y_cause2 <- vector(mode = "numeric", length = length(list_fg))


for (i in 1:length(list_fg)){
  
  
  brier_fg_cause1[i, ] <- list_fg[[i]]$Brier_cause1[1:16]
  brier_fg_cause2[i, ] <- list_fg[[i]]$Brier_cause2[1:16]
  auc_fg_cause1[i, ] <- list_fg[[i]]$AUC_cause1[1:16]
  auc_fg_cause2[i, ] <- list_fg[[i]]$AUC_cause2[1:16]
  
  calib_fg5y_cause1[i] <- list_fg[[i]]$MSE5_cause1
  calib_fg5y_cause2[i] <- list_fg[[i]]$MSE5_cause2
  calib_fg10y_cause1[i] <- list_fg[[i]]$MSE10_cause1
  calib_fg10y_cause2[i] <- list_fg[[i]]$MSE10_cause2 
  calib_fg15y_cause1[i] <- list_fg[[i]]$MSE15_cause1
  calib_fg15y_cause2[i] <- list_fg[[i]]$MSE15_cause2
  
}




##########################################
# For PLANNCR original
##########################################


# cause 1
brier_nnet_cause1 <- matrix(data = 0, nrow = length(list_nnet), ncol = 16) # Brier score until 15 years
auc_nnet_cause1 <- matrix(data = 0, nrow = length(list_nnet), ncol = 16) # AUC until 15 years
calib_nnet5y_cause1 <- vector(mode = "numeric", length = length(list_nnet))
calib_nnet10y_cause1 <- vector(mode = "numeric", length = length(list_nnet))
calib_nnet15y_cause1 <- vector(mode = "numeric", length = length(list_nnet))

# cause 2
brier_nnet_cause2 <- matrix(data = 0, nrow = length(list_nnet), ncol = 16) # Brier score until 15 years
auc_nnet_cause2 <- matrix(data = 0, nrow = length(list_nnet), ncol = 16) # AUC until 15 years
calib_nnet5y_cause2 <- vector(mode = "numeric", length = length(list_nnet))
calib_nnet10y_cause2 <- vector(mode = "numeric", length = length(list_nnet))
calib_nnet15y_cause2 <- vector(mode = "numeric", length = length(list_nnet))


for (i in 1:length(list_nnet)){
  
  
  brier_nnet_cause1[i, ] <- list_nnet[[i]]$Brier_cause1[1:16]
  brier_nnet_cause2[i, ] <- list_nnet[[i]]$Brier_cause2[1:16]
  auc_nnet_cause1[i, ] <- list_nnet[[i]]$AUC_cause1[1:16]
  auc_nnet_cause2[i, ] <- list_nnet[[i]]$AUC_cause2[1:16]
  
  calib_nnet5y_cause1[i] <- list_nnet[[i]]$MSE5_cause1
  calib_nnet5y_cause2[i] <- list_nnet[[i]]$MSE5_cause2
  calib_nnet10y_cause1[i] <- list_nnet[[i]]$MSE10_cause1
  calib_nnet10y_cause2[i] <- list_nnet[[i]]$MSE10_cause2 
  calib_nnet15y_cause1[i] <- list_nnet[[i]]$MSE15_cause1
  calib_nnet15y_cause2[i] <- list_nnet[[i]]$MSE15_cause2
  
}


##########################################
# For PLANNCR extended
##########################################

# cause 1
brier_keras_cause1 <- matrix(data = 0, nrow = length(list_keras), ncol = 16) # Brier score until 15 years
auc_keras_cause1 <- matrix(data = 0, nrow = length(list_keras), ncol = 16) # AUC until 15 years
calib_keras5y_cause1 <- vector(mode = "numeric", length = length(list_keras))
calib_keras10y_cause1 <- vector(mode = "numeric", length = length(list_keras))
calib_keras15y_cause1 <- vector(mode = "numeric", length = length(list_keras))

# cause 2
brier_keras_cause2 <- matrix(data = 0, nrow = length(list_keras), ncol = 16) # Brier score until 15 years
auc_keras_cause2 <- matrix(data = 0, nrow = length(list_keras), ncol = 16) # AUC until 15 years
calib_keras5y_cause2 <- vector(mode = "numeric", length = length(list_keras))
calib_keras10y_cause2 <- vector(mode = "numeric", length = length(list_keras))
calib_keras15y_cause2 <- vector(mode = "numeric", length = length(list_keras))


for (i in 1:length(list_keras)){
  
  
  brier_keras_cause1[i, ] <- list_keras[[i]]$Brier_cause1[1:16]
  brier_keras_cause2[i, ] <- list_keras[[i]]$Brier_cause2[1:16]
  auc_keras_cause1[i, ] <- list_keras[[i]]$AUC_cause1[1:16]
  auc_keras_cause2[i, ] <- list_keras[[i]]$AUC_cause2[1:16]
  
  calib_keras5y_cause1[i] <- list_keras[[i]]$MSE5_cause1
  calib_keras5y_cause2[i] <- list_keras[[i]]$MSE5_cause2
  calib_keras10y_cause1[i] <- list_keras[[i]]$MSE10_cause1
  calib_keras10y_cause2[i] <- list_keras[[i]]$MSE10_cause2 
  calib_keras15y_cause1[i] <- list_keras[[i]]$MSE15_cause1
  calib_keras15y_cause2[i] <- list_keras[[i]]$MSE15_cause2
  
}



##########################################
# For RSFCR
##########################################

# cause 1
brier_rsf_cause1 <- matrix(data = 0, nrow = length(list_rsf), ncol = 16) # Brier score until 15 years
auc_rsf_cause1 <- matrix(data = 0, nrow = length(list_rsf), ncol = 16) # AUC until 15 years
calib_rsf5y_cause1 <- vector(mode = "numeric", length = length(list_rsf))
calib_rsf10y_cause1 <- vector(mode = "numeric", length = length(list_rsf))
calib_rsf15y_cause1 <- vector(mode = "numeric", length = length(list_rsf))

# cause 2
brier_rsf_cause2 <- matrix(data = 0, nrow = length(list_rsf), ncol = 16) # Brier score until 15 years
auc_rsf_cause2 <- matrix(data = 0, nrow = length(list_rsf), ncol = 16) # AUC until 15 years
calib_rsf5y_cause2 <- vector(mode = "numeric", length = length(list_rsf))
calib_rsf10y_cause2 <- vector(mode = "numeric", length = length(list_rsf))
calib_rsf15y_cause2 <- vector(mode = "numeric", length = length(list_rsf))


for (i in 1:length(list_rsf)){
  
  
  brier_rsf_cause1[i, ] <- list_rsf[[i]]$Brier_cause1[1:16]
  brier_rsf_cause2[i, ] <- list_rsf[[i]]$Brier_cause2[1:16]
  auc_rsf_cause1[i, ] <- list_rsf[[i]]$AUC_cause1[1:16]
  auc_rsf_cause2[i, ] <- list_rsf[[i]]$AUC_cause2[1:16]
  
  calib_rsf5y_cause1[i] <- list_rsf[[i]]$MSE5_cause1
  calib_rsf5y_cause2[i] <- list_rsf[[i]]$MSE5_cause2
  calib_rsf10y_cause1[i] <- list_rsf[[i]]$MSE10_cause1
  calib_rsf10y_cause2[i] <- list_rsf[[i]]$MSE10_cause2 
  calib_rsf15y_cause1[i] <- list_rsf[[i]]$MSE15_cause1
  calib_rsf15y_cause2[i] <- list_rsf[[i]]$MSE15_cause2
  
}



# Bargraph for Brier score - AUC (for the event of interest: disease relapse)

# at 5 years

line1 <- data.frame(brier = mean(brier_csc_cause1[, 6], na.rm = TRUE),
                    brier_left = quant_low(brier_csc_cause1[, 6]),
                    brier_right = quant_high(brier_csc_cause1[, 6]),
                    auc = mean(auc_csc_cause1[, 6], na.rm = TRUE),
                    auc_left = quant_low(auc_csc_cause1[, 6]),
                    auc_right = quant_high(auc_csc_cause1[, 6]),
                    Model = "Cause-specific Cox",
                    Time = "5 years")


line2 <- data.frame(brier = mean(brier_fg_cause1[, 6], na.rm = TRUE),
                    brier_left = quant_low(brier_fg_cause1[, 6]),
                    brier_right = quant_high(brier_fg_cause1[, 6]),
                    auc = mean(auc_fg_cause1[, 6], na.rm = TRUE),
                    auc_left = quant_low(auc_fg_cause1[, 6]),
                    auc_right = quant_high(auc_fg_cause1[, 6]),
                    Model = "Fine-Gray",
                    Time = "5 years")


line3 <- data.frame(brier = mean(brier_nnet_cause1[, 6], na.rm = TRUE),
                    brier_left = quant_low(brier_nnet_cause1[, 6]),
                    brier_right = quant_high(brier_nnet_cause1[, 6]),
                    auc = mean(auc_nnet_cause1[, 6], na.rm = TRUE),
                    auc_left = quant_low(auc_nnet_cause1[, 6]),
                    auc_right = quant_high(auc_nnet_cause1[, 6]),
                    Model = "PLANNCR original",
                    Time = "5 years")

line4 <- data.frame(brier = mean(brier_keras_cause1[, 6], na.rm = TRUE),
                    brier_left = quant_low(brier_keras_cause1[, 6]),
                    brier_right = quant_high(brier_keras_cause1[, 6]),
                    auc = mean(auc_keras_cause1[, 6], na.rm = TRUE),
                    auc_left = quant_low(auc_keras_cause1[, 6]),
                    auc_right = quant_high(auc_keras_cause1[, 6]),
                    Model = "PLANNCR extended",
                    Time = "5 years")

line5 <- data.frame(brier = mean(brier_rsf_cause1[, 6], na.rm = TRUE),
                    brier_left = quant_low(brier_rsf_cause1[, 6]),
                    brier_right = quant_high(brier_rsf_cause1[, 6]),
                    auc = mean(auc_rsf_cause1[, 6], na.rm = TRUE),
                    auc_left = quant_low(auc_rsf_cause1[, 6]),
                    auc_right = quant_high(auc_rsf_cause1[, 6]),
                    Model = "RSFCR",
                    Time = "5 years")



# at 10 years

line6 <- data.frame(brier = mean(brier_csc_cause1[, 11], na.rm = TRUE),
                    brier_left = quant_low(brier_csc_cause1[, 11]),
                    brier_right = quant_high(brier_csc_cause1[, 11]),
                    auc = mean(auc_csc_cause1[, 11], na.rm = TRUE),
                    auc_left = quant_low(auc_csc_cause1[, 11]),
                    auc_right = quant_high(auc_csc_cause1[, 11]),
                    Model = "Cause-specific Cox",
                    Time = "10 years")


line7 <- data.frame(brier = mean(brier_fg_cause1[, 11], na.rm = TRUE),
                    brier_left = quant_low(brier_fg_cause1[, 11]),
                    brier_right = quant_high(brier_fg_cause1[, 11]),
                    auc = mean(auc_fg_cause1[, 11], na.rm = TRUE),
                    auc_left = quant_low(auc_fg_cause1[, 11]),
                    auc_right = quant_high(auc_fg_cause1[, 11]),
                    Model = "Fine-Gray",
                    Time = "10 years")


line8 <- data.frame(brier = mean(brier_nnet_cause1[, 11], na.rm = TRUE),
                    brier_left = quant_low(brier_nnet_cause1[, 11]),
                    brier_right = quant_high(brier_nnet_cause1[, 11]),
                    auc = mean(auc_nnet_cause1[, 11], na.rm = TRUE),
                    auc_left = quant_low(auc_nnet_cause1[, 11]),
                    auc_right = quant_high(auc_nnet_cause1[, 11]),
                    Model = "PLANNCR original",
                    Time = "10 years")

line9 <- data.frame(brier = mean(brier_keras_cause1[, 11], na.rm = TRUE),
                    brier_left = quant_low(brier_keras_cause1[, 11]),
                    brier_right = quant_high(brier_keras_cause1[, 11]),
                    auc = mean(auc_keras_cause1[, 11], na.rm = TRUE),
                    auc_left = quant_low(auc_keras_cause1[, 11]),
                    auc_right = quant_high(auc_keras_cause1[, 11]),
                    Model = "PLANNCR extended",
                    Time = "10 years")

line10 <- data.frame(brier = mean(brier_rsf_cause1[, 11], na.rm = TRUE),
                    brier_left = quant_low(brier_rsf_cause1[, 11]),
                    brier_right = quant_high(brier_rsf_cause1[, 11]),
                    auc = mean(auc_rsf_cause1[, 11], na.rm = TRUE),
                    auc_left = quant_low(auc_rsf_cause1[, 11]),
                    auc_right = quant_high(auc_rsf_cause1[, 11]),
                    Model = "RSFCR",
                    Time = "10 years")



# at 15 years

line11 <- data.frame(brier = mean(brier_csc_cause1[, 16], na.rm = TRUE),
                    brier_left = quant_low(brier_csc_cause1[, 16]),
                    brier_right = quant_high(brier_csc_cause1[, 16]),
                    auc = mean(auc_csc_cause1[, 16], na.rm = TRUE),
                    auc_left = quant_low(auc_csc_cause1[, 16]),
                    auc_right = quant_high(auc_csc_cause1[, 16]),
                    Model = "Cause-specific Cox",
                    Time = "15 years")


line12 <- data.frame(brier = mean(brier_fg_cause1[, 16], na.rm = TRUE),
                    brier_left = quant_low(brier_fg_cause1[, 16]),
                    brier_right = quant_high(brier_fg_cause1[, 16]),
                    auc = mean(auc_fg_cause1[, 16], na.rm = TRUE),
                    auc_left = quant_low(auc_fg_cause1[, 16]),
                    auc_right = quant_high(auc_fg_cause1[, 16]),
                    Model = "Fine-Gray",
                    Time = "15 years")


line13 <- data.frame(brier = mean(brier_nnet_cause1[, 16], na.rm = TRUE),
                    brier_left = quant_low(brier_nnet_cause1[, 16]),
                    brier_right = quant_high(brier_nnet_cause1[, 16]),
                    auc = mean(auc_nnet_cause1[, 16], na.rm = TRUE),
                    auc_left = quant_low(auc_nnet_cause1[, 16]),
                    auc_right = quant_high(auc_nnet_cause1[, 16]),
                    Model = "PLANNCR original",
                    Time = "15 years")

line14 <- data.frame(brier = mean(brier_keras_cause1[, 16], na.rm = TRUE),
                    brier_left = quant_low(brier_keras_cause1[, 16]),
                    brier_right = quant_high(brier_keras_cause1[, 16]),
                    auc = mean(auc_keras_cause1[, 16], na.rm = TRUE),
                    auc_left = quant_low(auc_keras_cause1[, 16]),
                    auc_right = quant_high(auc_keras_cause1[, 16]),
                    Model = "PLANNCR extended",
                    Time = "15 years")

line15 <- data.frame(brier = mean(brier_rsf_cause1[, 16], na.rm = TRUE),
                    brier_left = quant_low(brier_rsf_cause1[, 16]),
                    brier_right = quant_high(brier_rsf_cause1[, 16]),
                    auc = mean(auc_rsf_cause1[, 16], na.rm = TRUE),
                    auc_left = quant_low(auc_rsf_cause1[, 16]),
                    auc_right = quant_high(auc_rsf_cause1[, 16]),
                    Model = "RSFCR",
                    Time = "15 years")




df <- rbind(line1, line2, line3, line4, line5, line6, line7, line8,
            line9, line10, line11, line12, line13, line14, line15)

df$Model <- as.factor(df$Model)
df$Model <- factor(df$Model, levels = c("Cause-specific Cox", "Fine-Gray", "PLANNCR original",
                                         "PLANNCR extended", "RSFCR"))
df$Time <- as.factor(df$Time)
df$Time <- factor(df$Time, levels = c("5 years", "10 years", "15 years"))



# For the Brier scores

# Use 95% confidence intervals 
brier_c1 <- ggplot(df, aes(x=Time, y=brier, fill = Model)) + 
  geom_bar(position=position_dodge(), stat="identity") +
  labs(title = " ", x = "Time",
       y = "Brier score (for disease relapse)", fill = "Model") +
  scale_y_continuous(breaks = c(0, 0.05, 0.10, 0.15, 0.20, 0.25), limits = c(0, 0.275)) +
  geom_errorbar(aes(ymin=brier_left, ymax=brier_right),
               size = 0.5,    # Thinner lines
               width = 0.2,                    # Width of the error bars
               position=position_dodge(.9)) +
  theme(axis.text.x = element_text(face="bold", color="#993333", 
                                   size=11)) +
  theme(legend.position = "top") # Remove legend by setting to "none" 
# + theme_classic() 


# For the AUC

auc_c1 <- ggplot(df, aes(x=Time, y=auc, fill = Model)) + 
  geom_bar(position=position_dodge(), stat="identity") +
  labs(title = " ", x = "Time",
       y = "AUC (for disease relapse)", fill = "Model") +
  scale_y_continuous(breaks = c(0, 0.20, 0.40, 0.60, 0.80, 1), limits = c(0, 1)) +
  geom_errorbar(aes(ymin=auc_left, ymax=auc_right),
                size = 0.5,    # Thinner lines
                width = 0.2,                    # Width of the error bars
                position=position_dodge(.9)) +
  theme(axis.text.x = element_text(face="bold", color="#993333", 
                                   size=11)) +
  theme(legend.position = "top") # Remove legend by setting to "none" 
# + theme_classic() 


gridExtra::grid.arrange(brier_c1, auc_c1, ncol = 2)



# for supplementary material


# Bargraph for Brier score - AUC (for the competing event death)

# at 5 years

line16 <- data.frame(brier = mean(brier_csc_cause2[, 6], na.rm = TRUE),
                    brier_left = quant_low(brier_csc_cause2[, 6]),
                    brier_right = quant_high(brier_csc_cause2[, 6]),
                    auc = mean(auc_csc_cause2[, 6], na.rm = TRUE),
                    auc_left = quant_low(auc_csc_cause2[, 6]),
                    auc_right = quant_high(auc_csc_cause2[, 6]),
                    Model = "Cause-specific Cox",
                    Time = "5 years")


line17 <- data.frame(brier = mean(brier_fg_cause2[, 6], na.rm = TRUE),
                    brier_left = quant_low(brier_fg_cause2[, 6]),
                    brier_right = quant_high(brier_fg_cause2[, 6]),
                    auc = mean(auc_fg_cause2[, 6], na.rm = TRUE),
                    auc_left = quant_low(auc_fg_cause2[, 6]),
                    auc_right = quant_high(auc_fg_cause2[, 6]),
                    Model = "Fine-Gray",
                    Time = "5 years")


line18 <- data.frame(brier = mean(brier_nnet_cause2[, 6], na.rm = TRUE),
                    brier_left = quant_low(brier_nnet_cause2[, 6]),
                    brier_right = quant_high(brier_nnet_cause2[, 6]),
                    auc = mean(auc_nnet_cause2[, 6], na.rm = TRUE),
                    auc_left = quant_low(auc_nnet_cause2[, 6]),
                    auc_right = quant_high(auc_nnet_cause2[, 6]),
                    Model = "PLANNCR original",
                    Time = "5 years")

line19 <- data.frame(brier = mean(brier_keras_cause2[, 6], na.rm = TRUE),
                    brier_left = quant_low(brier_keras_cause2[, 6]),
                    brier_right = quant_high(brier_keras_cause2[, 6]),
                    auc = mean(auc_keras_cause2[, 6], na.rm = TRUE),
                    auc_left = quant_low(auc_keras_cause2[, 6]),
                    auc_right = quant_high(auc_keras_cause2[, 6]),
                    Model = "PLANNCR extended",
                    Time = "5 years")

line20 <- data.frame(brier = mean(brier_rsf_cause2[, 6], na.rm = TRUE),
                    brier_left = quant_low(brier_rsf_cause2[, 6]),
                    brier_right = quant_high(brier_rsf_cause2[, 6]),
                    auc = mean(auc_rsf_cause2[, 6], na.rm = TRUE),
                    auc_left = quant_low(auc_rsf_cause2[, 6]),
                    auc_right = quant_high(auc_rsf_cause2[, 6]),
                    Model = "RSFCR",
                    Time = "5 years")



# at 10 years

line21 <- data.frame(brier = mean(brier_csc_cause2[, 11], na.rm = TRUE),
                    brier_left = quant_low(brier_csc_cause2[, 11]),
                    brier_right = quant_high(brier_csc_cause2[, 11]),
                    auc = mean(auc_csc_cause2[, 11], na.rm = TRUE),
                    auc_left = quant_low(auc_csc_cause2[, 11]),
                    auc_right = quant_high(auc_csc_cause2[, 11]),
                    Model = "Cause-specific Cox",
                    Time = "10 years")


line22 <- data.frame(brier = mean(brier_fg_cause2[, 11], na.rm = TRUE),
                    brier_left = quant_low(brier_fg_cause2[, 11]),
                    brier_right = quant_high(brier_fg_cause2[, 11]),
                    auc = mean(auc_fg_cause2[, 11], na.rm = TRUE),
                    auc_left = quant_low(auc_fg_cause2[, 11]),
                    auc_right = quant_high(auc_fg_cause2[, 11]),
                    Model = "Fine-Gray",
                    Time = "10 years")


line23 <- data.frame(brier = mean(brier_nnet_cause2[, 11], na.rm = TRUE),
                    brier_left = quant_low(brier_nnet_cause2[, 11]),
                    brier_right = quant_high(brier_nnet_cause2[, 11]),
                    auc = mean(auc_nnet_cause2[, 11], na.rm = TRUE),
                    auc_left = quant_low(auc_nnet_cause2[, 11]),
                    auc_right = quant_high(auc_nnet_cause2[, 11]),
                    Model = "PLANNCR original",
                    Time = "10 years")

line24 <- data.frame(brier = mean(brier_keras_cause2[, 11], na.rm = TRUE),
                    brier_left = quant_low(brier_keras_cause2[, 11]),
                    brier_right = quant_high(brier_keras_cause2[, 11]),
                    auc = mean(auc_keras_cause2[, 11], na.rm = TRUE),
                    auc_left = quant_low(auc_keras_cause2[, 11]),
                    auc_right = quant_high(auc_keras_cause2[, 11]),
                    Model = "PLANNCR extended",
                    Time = "10 years")

line25 <- data.frame(brier = mean(brier_rsf_cause2[, 11], na.rm = TRUE),
                     brier_left = quant_low(brier_rsf_cause2[, 11]),
                     brier_right = quant_high(brier_rsf_cause2[, 11]),
                     auc = mean(auc_rsf_cause2[, 11], na.rm = TRUE),
                     auc_left = quant_low(auc_rsf_cause2[, 11]),
                     auc_right = quant_high(auc_rsf_cause2[, 11]),
                     Model = "RSFCR",
                     Time = "10 years")



# at 15 years

line26 <- data.frame(brier = mean(brier_csc_cause2[, 16], na.rm = TRUE),
                     brier_left = quant_low(brier_csc_cause2[, 16]),
                     brier_right = quant_high(brier_csc_cause2[, 16]),
                     auc = mean(auc_csc_cause2[, 16], na.rm = TRUE),
                     auc_left = quant_low(auc_csc_cause2[, 16]),
                     auc_right = quant_high(auc_csc_cause2[, 16]),
                     Model = "Cause-specific Cox",
                     Time = "15 years")


line27 <- data.frame(brier = mean(brier_fg_cause2[, 16], na.rm = TRUE),
                     brier_left = quant_low(brier_fg_cause2[, 16]),
                     brier_right = quant_high(brier_fg_cause2[, 16]),
                     auc = mean(auc_fg_cause2[, 16], na.rm = TRUE),
                     auc_left = quant_low(auc_fg_cause2[, 16]),
                     auc_right = quant_high(auc_fg_cause2[, 16]),
                     Model = "Fine-Gray",
                     Time = "15 years")


line28 <- data.frame(brier = mean(brier_nnet_cause2[, 16], na.rm = TRUE),
                     brier_left = quant_low(brier_nnet_cause2[, 16]),
                     brier_right = quant_high(brier_nnet_cause2[, 16]),
                     auc = mean(auc_nnet_cause2[, 16], na.rm = TRUE),
                     auc_left = quant_low(auc_nnet_cause2[, 16]),
                     auc_right = quant_high(auc_nnet_cause2[, 16]),
                     Model = "PLANNCR original",
                     Time = "15 years")

line29 <- data.frame(brier = mean(brier_keras_cause2[, 16], na.rm = TRUE),
                     brier_left = quant_low(brier_keras_cause2[, 16]),
                     brier_right = quant_high(brier_keras_cause2[, 16]),
                     auc = mean(auc_keras_cause2[, 16], na.rm = TRUE),
                     auc_left = quant_low(auc_keras_cause2[, 16]),
                     auc_right = quant_high(auc_keras_cause2[, 16]),
                     Model = "PLANNCR extended",
                     Time = "15 years")

line30 <- data.frame(brier = mean(brier_rsf_cause2[, 16], na.rm = TRUE),
                     brier_left = quant_low(brier_rsf_cause2[, 16]),
                     brier_right = quant_high(brier_rsf_cause2[, 16]),
                     auc = mean(auc_rsf_cause2[, 16], na.rm = TRUE),
                     auc_left = quant_low(auc_rsf_cause2[, 16]),
                     auc_right = quant_high(auc_rsf_cause2[, 16]),
                     Model = "RSFCR",
                     Time = "15 years")




df2 <- rbind(line16, line17, line18, line19, line20, line21, line22, line23,
            line24, line25, line26, line27, line28, line29, line30)

df2$Model <- as.factor(df2$Model)
df2$Model <- factor(df2$Model, levels = c("Cause-specific Cox", "Fine-Gray", "PLANNCR original",
                                        "PLANNCR extended", "RSFCR"))
df2$Time <- as.factor(df2$Time)
df2$Time <- factor(df2$Time, levels = c("5 years", "10 years", "15 years"))



# For the Brier scores

# Use 95% confidence intervals 
brier_c2 <- ggplot(df2, aes(x=Time, y=brier, fill = Model)) + 
  geom_bar(position=position_dodge(), stat="identity") +
  labs(title = " ", x = "Time",
       y = "Brier score (for death)", fill = "Model") +
  scale_y_continuous(breaks = c(0, 0.05, 0.10, 0.15, 0.20, 0.25), limits = c(0, 0.25)) +
  geom_errorbar(aes(ymin=brier_left, ymax=brier_right),
                size = 0.5,    # Thinner lines
                width = 0.2,                    # Width of the error bars
                position=position_dodge(.9)) +
  theme(axis.text.x = element_text(face="bold", color="#993333", 
                                   size=11)) +
  theme(legend.position = "top") # Remove legend by setting to "none" 
# + theme_classic() 


# For the AUC

auc_c2 <- ggplot(df, aes(x=Time, y=auc, fill = Model)) + 
  geom_bar(position=position_dodge(), stat="identity") +
  labs(title = " ", x = "Time",
       y = "AUC (for death)", fill = "Model") +
  scale_y_continuous(breaks = c(0, 0.20, 0.40, 0.60, 0.80, 1), limits = c(0, 1)) +
  geom_errorbar(aes(ymin=auc_left, ymax=auc_right),
                size = 0.5,    # Thinner lines
                width = 0.2,                    # Width of the error bars
                position=position_dodge(.9)) +
  theme(axis.text.x = element_text(face="bold", color="#993333", 
                                   size=11)) +
  theme(legend.position = "top") # Remove legend by setting to "none" 
# + theme_classic() 


gridExtra::grid.arrange(brier_c2, auc_c2, ncol = 2)





