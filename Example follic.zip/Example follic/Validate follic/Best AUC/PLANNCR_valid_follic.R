
# tuning follic
# with bootstrap, search for hyperparameters afresh for each loop
# supervised learning steps inside the loop
# B = 100
# original data  ---> N = 541 develop, N = OOB validate

library(riskRegression)
library(randomForestSRC)
library(prodlim)
library(ggplot2)
library(survival)
library(data.table)
library(nnet)
library(keras)
library(tictoc)
library(randomForestSRC)
source("functions_nncr.R")

# dataset 2
data("follic") # n = 541, p = 4
# define ids
follic$id <- 1:nrow(follic)
follic$clinstg <- as.factor(follic$clinstg)

# apply administrative censoring at 20 years
follic$status <- follic$status*(follic$time <= 20)
follic$time <- pmin(follic$time, 20)

# variables: age, hgb, clinstg (1 or 2), ch (N or Y)


#############################
# bootstrapping
#############################

set.seed(12345)
n <- nrow(follic)
B <- 100

# getting the bootstrap samples without loops
# each column is a bootstrap re-sample
boot_samples <- matrix(sample(follic$id, size = n*B, replace = TRUE),
                       nrow = n, ncol = B)


# create objects to store the statistics
# create a loop to calculate the statistics

# initialize objects
list_nnet <- vector(mode = "list", length = ncol(boot_samples))  
list_keras <- vector(mode = "list", length = ncol(boot_samples))  
# list_rsf <- vector(mode = "list", length = ncol(boot_samples))  
# list_csc <- vector(mode = "list", length = ncol(boot_samples))  
# list_fg <- vector(mode = "list", length = ncol(boot_samples))  

# run the OOB validation
tic("Running the OOB validation")


for (i in 1:B) {
  
  cat("Started iteration i = ", i, "out of", B, "\n")
  # use the proper bootstrap column
  indices <- boot_samples[, i]
  oob <- follic$id[!follic$id %in% indices] # select oob patients
  
  #############################
  # training data
  #############################
  
  # scale continuous variables 
  follic2 <- follic[indices, ] # create df 2
  follic2$id <- 1:nrow(follic2)
  follic2$age <- scale(follic2$age)
  follic2$hgb <- scale(follic2$hgb)
  
  
  #############################
  # validation data
  #############################
  
  follic3 <- follic[oob, ]
  
  # if there is no competing cause on test data move to next i
  if (sum(follic3$status == 2) == 0)  {
    no_cr <- c(no_cr, i) # expanding vector with elements where OOB test set has no CR
    next 
  }
  
  follic3$age <- scale(follic3$age)
  follic3$hgb <- scale(follic3$hgb)
  
  #####################################
  # create the necessary long formats
  #####################################
  
  train_long_follic <- train_creator_follic(data = follic2)
  train_long_follic <- model.matrix(~., train_long_follic)[, -1] 
  
  train_x_follic <- train_long_follic[, c(4:7, 9)] # p = 4 variables + time interval
  dimnames(train_x_follic) <- NULL # the object must have empty dimnames
  train_y_follic <- train_long_follic[, (ncol(train_long_follic) - 2):ncol(train_long_follic)]
  dimnames(train_y_follic) <- NULL
  
  test_long_follic <- test_creator_follic(data = follic2)
  test_long_follic <- model.matrix(~., test_long_follic)[, -1]
  
  test_x_follic <- test_long_follic[, c(4:7, 9)] # p = 4 variables + time interval
  dimnames(test_x_follic) <- NULL # the object must have empty dimnames
  test_y_follic <- test_long_follic[, (ncol(train_long_follic) - 2):ncol(train_long_follic)]
  dimnames(test_y_follic) <- NULL
  
  valid_long_follic <- test_creator_follic(data = follic3)
  valid_long_follic <- model.matrix(~., valid_long_follic)[, -1]
  
  
  # build the model in nnet
  set.seed(12345)
  fit_nnet <- nnet(x = train_x_follic, y = train_y_follic,
                   size = 1, decay = 0.5, # best AUC (previous 1, 0.3)
                   maxit = 500, trace = FALSE, softmax = TRUE)
  
  
  results1 <- measures_nnet_follic(trained_model = fit_nnet,
                                  datashort = follic3, 
                                  datalong = valid_long_follic)
  list_nnet[[i]] <- results1
  
  # # build the model in keras
  # # set global default to never show metrics
  # options(keras.view_metrics = FALSE)
  k_clear_session() # to avoid clutter from old models / layers in cross validation
  tensorflow::tf$random$set_seed(12345) # for update to TensorFlow 2.0
  # model with one hidden layer

  # Initialize a sequential model
  fit_keras1 <- keras_model_sequential()

  # Add layers to the model
  fit_keras1 %>%
    layer_dense(units = 2, activation = 'relu',
                input_shape = ncol(train_x_follic)) %>%
    layer_dropout(rate = 0.4) %>%
    layer_dense(units = 3, activation = 'softmax')

  # Compile the model
  fit_keras1 %>% compile(
    loss = 'categorical_crossentropy', # for multi-class classification problem
    optimizer = optimizer_sgd(learning_rate = 0.1, momentum = 0.8)
    #, metrics = c("accuracy")
  )
  early_stopping <- callback_early_stopping(monitor = 'val_loss', patience = 3)

  result_keras <- fit_keras1 %>% fit(
    train_x_follic,
    train_y_follic,
    epochs = 50,
    batch_size = 32,
    validation_data = list(test_x_follic, test_y_follic),
    class_weight = list("0" = 1, "1" = 1, "2" = 1),
    callbacks = c(early_stopping),
    verbose = 0 # don't display progress bar
  )

  results2 <- measures_keras_follic(trained_model = fit_keras1,
                                   datashort = follic3,
                                   datalong = valid_long_follic)

  list_keras[[i]] <- results2
  
  
  
  # build Cause-Specific Cox
  # cox.fit <- CSC(Hist(time,status)~ age + hgb + clinstg + ch,
  #                data=follic2)
  # 
  # r1 <- predictRisk(cox.fit,newdata=as.data.table(follic3), times=0:20, cause=1)
  # r2 <- predictRisk(cox.fit,newdata=as.data.table(follic3), times=0:20, cause=2)
  # 
  # results3 <- measures_follic(risk_mat1 = r1, risk_mat2 = r2, datashort = follic3)  
  # list_csc[[i]] <- results3
  
  # # build Fine - Gray
  # fg.fit <- FGR(Hist(time,status)~ age + hgb + clinstg + ch,
  #               data=follic2, cause=1)
  # 
  # r1b <- predictRisk(fg.fit, newdata=as.data.table(follic3), times=0:20)
  # 
  # fg.fit2 <- FGR(Hist(time,status)~ age + hgb + clinstg + ch,
  #                data=follic2, cause=2)
  # r2b <- predictRisk(fg.fit2, newdata=as.data.table(follic3), times=0:20)
  # 
  # results4 <- measures_follic(risk_mat1 = r1b, risk_mat2 = r2b, datashort = follic3)  
  # list_fg[[i]] <- results4
  
  # build RSF_CR
  # rsf.fit <- rfsrc(Surv(time, status) ~ age + hgb + clinstg + ch,
  #                  data = follic2, ntree = 1000, mtry = 3, nsplit = 2,
  #                  nodesize = 6, splitrule = "logrank", cause = 1, seed = 12345,
  #                  forest = TRUE, importance = FALSE)
  # 
  # r1c <- predictRisk(rsf.fit, newdata=as.data.table(follic3), times=0:20, cause=1)
  # r2c <- predictRisk(rsf.fit, newdata=as.data.table(follic3), times=0:20, cause=2)
  # 
  # #pred_test <- predict(rsf.fit, newdata = follic3)
  # results5 <- measures_follic(risk_mat1 = r1c, risk_mat2 = r2c, datashort = follic3)
  # list_rsf[[i]] <- results5
  
  
  
  
}

time_list <- toc()

cat((time_list$toc - time_list$tic) / 60, "minutes elapsed", "\n") 
# 8.843 minutes elapsed 


save(list_nnet, file = "results_nnet2.RData")
save(list_keras, file = "results_keras_relu_patience3_auc.RData")
#save(list_rsf, file = "results_rsf_logrank.RData")
#save(list_csc, file = "results_csc.RData")
#save(list_fg, file = "results_fg.RData")


# function that calculates the quantiles and the mean

summa <- function(x) {
  
  res1 <- round(quantile(x, probs = c(0, 0.025, 0.5, 0.975, 1), na.rm = TRUE), digits = 3)
  res2 <- round(mean(x, na.rm = TRUE), digits = 3)
  res3 <- round(sd(x, na.rm = TRUE), digits = 3)
  res <- c(res1[1:3], res2, res1[4:5], res3)
  names(res) <- c("Min.", "2.5% Qu.", "Median", "Mean", "97.5% Qu.", "Max.", "Sd.")
  return(res)
}


############################################################################
### enter the lists to calculate the measures - first for nnet
############################################################################

# cause 1
brier_nnet_cause1 <- matrix(data = 0, nrow = length(list_nnet), ncol = 16) # Brier score until 5 years
auc_nnet_cause1 <- matrix(data = 0, nrow = length(list_nnet), ncol = 16) # AUC until 5 years
calib_nnet5y_cause1 <- vector(mode = "numeric", length = length(list_nnet))
calib_nnet10y_cause1 <- vector(mode = "numeric", length = length(list_nnet))
calib_nnet15y_cause1 <- vector(mode = "numeric", length = length(list_nnet))

# cause 2
brier_nnet_cause2 <- matrix(data = 0, nrow = length(list_nnet), ncol = 16) # Brier score until 5 years
auc_nnet_cause2 <- matrix(data = 0, nrow = length(list_nnet), ncol = 16) # AUC until 5 years
calib_nnet5y_cause2 <- vector(mode = "numeric", length = length(list_nnet))
calib_nnet10y_cause2 <- vector(mode = "numeric", length = length(list_nnet))
calib_nnet15y_cause2 <- vector(mode = "numeric", length = length(list_nnet))


for (i in 1:length(list_nnet)){
  
   
    brier_nnet_cause1[i, ] <- list_nnet[[i]]$Brier_cause1[1:16]
    brier_nnet_cause2[i, ] <- list_nnet[[i]]$Brier_cause2[1:16]
    auc_nnet_cause1[i, ] <- list_nnet[[i]]$AUC_cause1[1:16]
    auc_nnet_cause2[i, ] <- list_nnet[[i]]$AUC_cause2[1:16]
    
    calib_nnet5y_cause1[i] <- list_nnet[[i]]$MSE5_cause1
    calib_nnet5y_cause2[i] <- list_nnet[[i]]$MSE5_cause2
    calib_nnet10y_cause1[i] <- list_nnet[[i]]$MSE10_cause1
    calib_nnet10y_cause2[i] <- list_nnet[[i]]$MSE10_cause2 
    calib_nnet15y_cause1[i] <- list_nnet[[i]]$MSE15_cause1
    calib_nnet15y_cause2[i] <- list_nnet[[i]]$MSE15_cause2
  
}

### cause 1
# brier score at 5 years
summa(brier_nnet_cause1[, 6])
# auc at 5 years
summa(auc_nnet_cause1[, 6]) 
# calibration error at 5 years
summa(calib_nnet5y_cause1)

### cause 2
# brier score at 5 years
summa(brier_nnet_cause2[, 6])
# auc at 5 years
summa(auc_nnet_cause2[, 6]) 
# calibration error at 5 years
summa(calib_nnet5y_cause2)


############################################################################
### enter the lists to calculate the measures - for keras
############################################################################

# cause 1
brier_keras_cause1 <- matrix(data = 0, nrow = length(list_keras), ncol = 16) # Brier score until 5 years
auc_keras_cause1 <- matrix(data = 0, nrow = length(list_keras), ncol = 16) # AUC until 5 years
calib_keras5y_cause1 <- vector(mode = "numeric", length = length(list_keras))
calib_keras10y_cause1 <- vector(mode = "numeric", length = length(list_keras))
calib_keras15y_cause1 <- vector(mode = "numeric", length = length(list_keras))

# cause 2
brier_keras_cause2 <- matrix(data = 0, nrow = length(list_keras), ncol = 16) # Brier score until 5 years
auc_keras_cause2 <- matrix(data = 0, nrow = length(list_keras), ncol = 16) # AUC until 5 years
calib_keras5y_cause2 <- vector(mode = "numeric", length = length(list_keras))
calib_keras10y_cause2 <- vector(mode = "numeric", length = length(list_keras))
calib_keras15y_cause2 <- vector(mode = "numeric", length = length(list_keras))


for (i in 1:length(list_keras)){
  
  
  brier_keras_cause1[i, ] <- list_keras[[i]]$Brier_cause1[1:16]
  brier_keras_cause2[i, ] <- list_keras[[i]]$Brier_cause2[1:16]
  auc_keras_cause1[i, ] <- list_keras[[i]]$AUC_cause1[1:16]
  auc_keras_cause2[i, ] <- list_keras[[i]]$AUC_cause2[1:16]
  
  calib_keras5y_cause1[i] <- list_keras[[i]]$MSE5_cause1
  calib_keras5y_cause2[i] <- list_keras[[i]]$MSE5_cause2
  calib_keras10y_cause1[i] <- list_keras[[i]]$MSE10_cause1
  calib_keras10y_cause2[i] <- list_keras[[i]]$MSE10_cause2 
  calib_keras15y_cause1[i] <- list_keras[[i]]$MSE15_cause1
  calib_keras15y_cause2[i] <- list_keras[[i]]$MSE15_cause2
  
}

### cause 1
# brier score at 5 years
summa(brier_keras_cause1[, 6])
# auc at 5 years
summa(auc_keras_cause1[, 6]) 
# calibration error at 5 years
summa(calib_keras5y_cause1)

### cause 2
# brier score at 5 years
summa(brier_keras_cause2[, 6])
# auc at 5 years
summa(auc_keras_cause2[, 6]) 
# calibration error at 5 years
summa(calib_keras5y_cause2)



