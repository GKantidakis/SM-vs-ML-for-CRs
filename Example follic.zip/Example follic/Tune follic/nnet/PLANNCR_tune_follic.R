
# tuning follic at 5 years
# with bootstrap, search for hyperparameters afresh for each loop
# supervised learning steps inside the loop
# B = 100?
# original data  ---> N = 541 develop, N = OOB validate

library(riskRegression)
library(prodlim)
library(ggplot2)
library(survival)
library(data.table)
library(nnet)
library(keras)
library(tictoc)
library(randomForestSRC)
source("functions_nncr.R")

data("follic") # n = 541, p = 4
# define ids
follic$id <- 1:nrow(follic)
follic$clinstg <- as.factor(follic$clinstg)

# apply administrative censoring at 20 years
follic$status <- follic$status*(follic$time <= 20)
follic$time <- pmin(follic$time, 20)
# variables: age, hgb, clinstg (1 or 2), ch (N or Y)


#############################
# bootstrapping
#############################

set.seed(12345)
n <- nrow(follic)
B <- 100

# getting the bootstrap samples without loops
# each column is a bootstrap re-sample
boot_samples <- matrix(sample(follic$id, size = n*B, replace = TRUE),
                       nrow = n, ncol = B)

# create objects to store the statistics
# create a loop to calculate the statistics

node_size <- seq(1, 5, by = 1) # grid of node sizes
#weight_decay <- c(0.001, 0.005, 0.01, 0.05, 0.1, 0.2, 0.3)
weight_decay <- c(0.01, 0.05, 0.1, 0.2, 0.3, 0.4, 0.5)
combis <- expand.grid(node_size, weight_decay) # 35 combinations

# initialize objects
mat_brier <-  matrix(0, nrow = B, ncol = nrow(combis))
mat_auc <- matrix(0, nrow = B, ncol = nrow(combis))
mat_calib <- matrix(0, nrow = B, ncol = nrow(combis))


# run the bootstrap training
tic("Running the bootstrap training")


for (i in 1:B) {
  
  cat("Started iteration i = ", i, "\n")
  # use the proper bootstrap column
  indices <- boot_samples[, i]
  
  follic2 <- follic[indices, ]
  follic2$id <- 1:nrow(follic2)
  
  # sample randomly 3/4 of data as train and 1/4 as test data per bootstrap sample
  set.seed(12345)
  vec <- sample(x = follic2$id, size = round((3/4)*nrow(follic2))) 
  follic2_train <- follic2[follic2$id %in% vec, ]
  follic2_test <- follic2[!(follic2$id %in% vec), ]
  
  # scale data
  follic2_train$age <- scale(follic2_train$age)
  follic2_train$hgb <- scale(follic2_train$hgb)
  follic2_test$age <- scale(follic2_test$age)
  follic2_test$hgb <- scale(follic2_test$hgb)
  
  train_long_follic <- train_creator_follic(data = follic2_train)
  # categorical variables to numerical (reference level redundant)
  train_long_follic <- model.matrix(~., train_long_follic)[, -1] 
  
  train_x_follic <- train_long_follic[, c(4:7, 9)] # p = 4 variables + time interval
  dimnames(train_x_follic) <- NULL # the object must have empty dimnames
  train_y_follic <- train_long_follic[, (ncol(train_long_follic) - 2):ncol(train_long_follic)]
  dimnames(train_y_follic) <- NULL
  
  test_long_follic <- test_creator_follic(data = follic2_test)
  # categorical variables to numerical (reference level redundant)
  test_long_follic <- model.matrix(~., test_long_follic)[, -1]
  
  test_x_follic <- test_long_follic[, c(4:7, 9)] # p = 4 variables + time interval
  dimnames(test_x_follic) <- NULL # the object must have empty dimnames
  test_y_follic <- test_long_follic[, (ncol(train_long_follic) - 2):ncol(train_long_follic)]
  dimnames(test_y_follic) <- NULL
  
  
  for (j in 1:nrow(combis)) { 
    
    cat("Testing combination number:", j, "of repeat", i, "out of", B, "\n")
    cat("calculating for node size:", combis[j, 1], "and weight decay", combis[j, 2], "...", "\n")

  # start building the model in nnet
  
  set.seed(12345)
  fit_nnet <- nnet(x = train_x_follic, y = train_y_follic,
                   size = combis[j, 1], decay = combis[j, 2],
                   maxit = 500, trace = FALSE, softmax = TRUE)
  
  
  results1 <- measures_nnet_follic(trained_model = fit_nnet,
                                  datashort = follic2_test, 
                                  datalong = test_long_follic)
  
  mat_brier[i, j] <- results1$Brier_cause1[6]
  mat_auc[i, j] <- results1$AUC_cause1[6]
  mat_calib[i, j] <- results1$MSE5_cause1
  
  
  cat("The Brier Score at 5 years is:", round(results1$Brier_cause1[6], 3),
      "and the AUC is:", round(results1$AUC_cause1[6], 3), "\n")
  
  }
  
  
}

time_list <- toc()

cat((time_list$toc - time_list$tic) / 60, "minutes elapsed", "\n") 


df_logistic_ovr <- as.data.frame(cbind(node_size = combis[, 1],
                                       weight_decay = combis[, 2],
                                       brier5 = colMeans(mat_brier),
                                       auc5 = colMeans(mat_auc),
                                       calib5 = colMeans(mat_calib, 
                                                          na.rm = TRUE)))  

save(df_logistic_ovr, file = "results_nnet_follic.RData")

ind <- head(order(df_logistic_ovr$brier5, decreasing = FALSE), 3)
df_logistic_ovr[ind, ]

ind2 <- head(order(df_logistic_ovr$auc5, decreasing = TRUE), 3)
df_logistic_ovr[ind2, ]

ind3 <- head(order(df_logistic_ovr$calib5, decreasing = FALSE), 3)
df_logistic_ovr[ind3, ]






