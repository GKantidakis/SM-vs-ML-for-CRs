
# tuning follic
# with bootstrap, search for hyperparameters afresh for each loop
# supervised learning steps inside the loop
# B = 100
# original data  ---> N = 541 develop, N = OOB validate

library(riskRegression)
library(randomForestSRC)
library(prodlim)
library(ggplot2)
library(survival)
library(data.table)
library(nnet)
library(keras)
library(tictoc)
source("functions_nncr.R")

data("follic") # n = 541, p = 4
# define ids
follic$id <- 1:nrow(follic)
follic$clinstg <- as.factor(follic$clinstg)

# apply administrative censoring at 20 years
follic$status <- follic$status*(follic$time <= 20)
follic$time <- pmin(follic$time, 20)
# variables: age, hgb, clinstg (1 or 2), ch (N or Y)


#############################
# bootstrapping
#############################

set.seed(12345)
n <- nrow(follic)
B <- 100

# getting the bootstrap samples without loops
# each column is a bootstrap re-sample
boot_samples <- matrix(sample(follic$id, size = n*B, replace = TRUE),
                       nrow = n, ncol = B)

# create objects to store the statistics
# create a loop to calculate the statistics


mtry <- seq(1, 3, by = 1) # grid of node sizes
nsplit <- c(2) # seq(2, 3, by = 1)
nodesize <- seq(10, 24, by = 2)
combis <- expand.grid(mtry, nsplit, nodesize) # 24 combinations

# initialize objects
mat_error <-  matrix(0, nrow = B, ncol = nrow(combis))
mat_calib <- matrix(0, nrow = B, ncol = nrow(combis))

# run the bootstrap training
tic("Running the bootstrap training")


for (i in 1:B) {
  
  cat("Started iteration i = ", i, "\n")
  # use the proper bootstrap column
  indices <- boot_samples[, i]
  
  follic2 <- follic[indices, ]
  follic2$id <- 1:nrow(follic2)
  
  # sample randomly 3/4 of data as train and 1/4 as test data per bootstrap sample
  set.seed(12345)
  vec <- sample(x = follic2$id, size = round((3/4)*nrow(follic2))) 
  follic2_train <- follic2[follic2$id %in% vec, ]
  follic2_test <- follic2[!(follic2$id %in% vec), ]
  
  # scale data
  follic2_train$age <- scale(follic2_train$age)
  follic2_train$hgb <- scale(follic2_train$hgb)
  follic2_test$age <- scale(follic2_test$age)
  follic2_test$hgb <- scale(follic2_test$hgb)
  
  for (j in 1:nrow(combis)) { 
    
    cat("Testing combination number:", j, "of repeat", i, "out of", B, "\n")
    cat("calculating for mtry:", combis[j, 1], "nsplit", combis[j, 2],
        "and nodesize", combis[j, 3], "...", "\n")

  # start building the rsf
  
  fit_rsf <- rfsrc(Surv(time, status) ~ age + hgb + clinstg + ch,
                   data = follic2_train, ntree = 1000, mtry = combis[j, 1],
                   nsplit = combis[j, 2], nodesize = combis[j, 3],
                   splitrule = "logrankCR", seed = 12345, # cause = 1, 
                   forest = TRUE, importance = FALSE)
  
  df <- data.frame(time = follic2_test$time,
                   status = follic2_test$status)

  r1c <- predictRisk(fit_rsf, newdata=as.data.table(follic2_test), times=0:20, cause=1)
  r2c <- predictRisk(fit_rsf, newdata=as.data.table(follic2_test), times=0:20, cause=2)

  pred_test <- predict(fit_rsf, newdata = follic2_test)
  results1 <- measures_follic(risk_mat1 = r1c, risk_mat2 = r2c, datashort = df)
  
  mat_error[i, j] <- pred_test$err.rate[pred_test$ntree] #OOB error for cause 1 (1 - C)
  mat_calib[i, j] <- results1$MSE5_cause1
  
  cat("The prediction error is:", round(pred_test$err.rate[pred_test$ntree], 3), "\n")
  
  }
  
  
}

time_list <- toc()

cat((time_list$toc - time_list$tic) / (60*60), "minutes elapsed", "\n") 


df_logrankCR_ovr <- as.data.frame(cbind(mtry = combis[, 1],
                                      nsplit = combis[, 2],
                                      nodesize = combis[, 3],
                                      error = colMeans(mat_error),
                                      calib5 = colMeans(mat_calib))) 

save(df_logrankCR_ovr, file = "results_rsf_logrankCR_follic2.RData")

ind <- head(order(df_logrankCR_ovr$error, decreasing = FALSE), 5)
df_logrankCR_ovr[ind, ]

ind2 <- head(order(df_logrankCR_ovr$calib5, decreasing = FALSE), 5)
df_logrankCR_ovr[ind2, ]








