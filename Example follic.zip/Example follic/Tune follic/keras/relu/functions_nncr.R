
# functions for the neural networks

library(survcomp)
library(fastDummies)
library(mstate)

###############################################################

train_creator_Melanoma <- function(data){
  
  N <- nrow(data)
  # assign survival times to 15 intervals, each is a 1-year period
  data$interval <- cut(data$time, breaks = c(0:11, max(data$time, 15)), labels = FALSE)
  data$survival <- cut(data$time, breaks = c(0:11, max(data$time, 15)), labels = FALSE)
  n.times <- data$interval
  data_long <- data[rep(seq_len(N), times = n.times), ]
  
  # create the correct interval enumeration
  for(i in unique(data_long$id)) {
    n_length <- length(data_long$interval[data_long$id == i])
    data_long$interval[data_long$id == i] <- 1:n_length
  }
  
  data_long$status_long <- vector(mode = "numeric",
                                  length = nrow(data_long))
  
  # put indication 1 on status at the interval that patient dies from Melanoma
  # and 2 from other cause
  for (i in 1:nrow(data_long)) {
    if (data_long$status[i] != data_long$status_long[i] &&
        data_long$survival[i] == data_long$interval[i])
      data_long$status_long[i] <- data_long$status[i]
  }
  
  # intervals <- dummy_cols(as.factor(data_long$interval))
  # colnames(intervals) <- gsub(".data", "interval", colnames(intervals))
  # data_long <- data.frame(data_long, intervals[, seq(2, max(n.times) + 1, by = 1)])
  
  events <- dummy_cols(as.factor(data_long$status_long))
  colnames(events) <- gsub(".data", "event", colnames(events))
  data_long <- data.frame(data_long, events[, seq(2, ncol(events), by = 1)])
  
  # interval scaled
  data_long$interval_scaled <- scale(data_long$interval)
  
  data_long <- data_long[, c("id", "time", "status", "invasion", "ici", 
                             "epicel", "ulcer", "sex", "age", "logthick",
                             "interval", "interval_scaled", "survival",
                             "status_long", "event_0", "event_1", "event_2" )]
  return(data_long)
  
}


###############################################################

# function that creates data in the right long format for test set
test_creator_Melanoma <- function(data){
  
  N <- nrow(data)
  # assign survival times to 15 intervals
  data$interval <- max(cut(data$time,
                           breaks = c(0:11, max(data$time, 15)),
                           labels = FALSE)) # replicate the test data 
  
  
  
  # the true interval survival
  data$survival <- cut(data$time,
                       breaks = c(0:11, max(data$time, 15)),
                       labels = FALSE) 
  
  
  data$id <- 1001:(1000 + N) # define the patient ids abstractly
  n.times <- data$interval
  data_long <- data[rep(seq_len(N), times = n.times), ]
  
  # create the correct interval enumeration
  for(i in unique(data_long$id)) {
    n_length <- length(data_long$interval[data_long$id == i])
    data_long$interval[data_long$id == i] <- 1:n_length
    
  }
  
  data_long$status_long <- vector(mode = "numeric",
                                  length = nrow(data_long))
  
  # put indication 1 on status at the intervals on
  # which a patient has died from Melanoma and 2 from other cause
  for (i in 1:nrow(data_long)) {
    if (data_long$status[i] != data_long$status_long[i] && 
        data_long$survival[i] <= data_long$interval[i]) 
      data_long$status_long[i] <- data_long$status[i]
  }
  
  
  # intervals2 <- dummy_cols(as.factor(data_long$interval))
  # colnames(intervals2) <- gsub(".data", "interval", colnames(intervals2))
  # data_long <- data.frame(data_long, intervals2[, seq(2, max(n.times) + 1, by = 1)])
  
  
  events <- dummy_cols(as.factor(data_long$status_long))
  colnames(events) <- gsub(".data", "event", colnames(events))
  data_long <- data.frame(data_long, events[, seq(2, ncol(events), by = 1)])
  
  # interval scaled
  data_long$interval_scaled <- scale(data_long$interval)
  
  data_long <- data_long[, c("id", "time", "status", "invasion", "ici", 
                             "epicel", "ulcer", "sex", "age", "logthick",
                             "interval", "interval_scaled", "survival",
                             "status_long", "event_0", "event_1", "event_2" )]
  return(data_long)
  
}


train_creator_follic <- function(data){
  
  N <- nrow(data)
  # assign survival times to 20 intervals, each is a 1-year period
  data$interval <- cut(data$time, breaks = c(0:20), labels = FALSE)
  data$survival <- cut(data$time, breaks = c(0:20), labels = FALSE)
  n.times <- data$interval
  data_long <- data[rep(seq_len(N), times = n.times), ]
  
  # create the correct interval enumeration
  for(i in unique(data_long$id)) {
    n_length <- length(data_long$interval[data_long$id == i])
    data_long$interval[data_long$id == i] <- 1:n_length
  }
  
  data_long$status_long <- vector(mode = "numeric",
                                  length = nrow(data_long))
  
  # put indication 1 on status at the interval that relapses
  # and 2 that dies
  for (i in 1:nrow(data_long)) {
    if (data_long$status[i] != data_long$status_long[i] &&
        data_long$survival[i] == data_long$interval[i])
      data_long$status_long[i] <- data_long$status[i]
  }
  
  # intervals <- dummy_cols(as.factor(data_long$interval))
  # colnames(intervals) <- gsub(".data", "interval", colnames(intervals))
  # data_long <- data.frame(data_long, intervals[, seq(2, max(n.times) + 1, by = 1)])
  
  events <- dummy_cols(as.factor(data_long$status_long))
  colnames(events) <- gsub(".data", "event", colnames(events))
  data_long <- data.frame(data_long, events[, seq(2, ncol(events), by = 1)])
  
  # interval scaled
  data_long$interval_scaled <- scale(data_long$interval)
  
  
  data_long <- data_long[, c("id", "time", "status", "age", "hgb", "clinstg",
                             "ch",  "interval", "interval_scaled", "survival",
                             "status_long", "event_0", "event_1", "event_2" )]
  return(data_long)
  
}


# function that creates data in the right long format for test set
test_creator_follic <- function(data){
  
  N <- nrow(data)
  # assign survival times to 20 intervals
  data$interval <- max(cut(data$time,
                           breaks = c(0:20),
                           labels = FALSE)) # replicate the test data 
  
  # the true interval survival
  data$survival <- cut(data$time,
                       breaks = c(0:20),
                       labels = FALSE) 
  
  
  data$id <- 1001:(1000 + N) # define the patient ids abstractly
  n.times <- data$interval
  data_long <- data[rep(seq_len(N), times = n.times), ]
  
  # create the correct interval enumeration
  for(i in unique(data_long$id)) {
    n_length <- length(data_long$interval[data_long$id == i])
    data_long$interval[data_long$id == i] <- 1:n_length
    
  }
  
  data_long$status_long <- vector(mode = "numeric",
                                  length = nrow(data_long))
  
  # put indication 1 on status at the intervals on
  # which a patient has died from Melanoma and 2 from other cause
  for (i in 1:nrow(data_long)) {
    if (data_long$status[i] != data_long$status_long[i] && 
        data_long$survival[i] <= data_long$interval[i]) 
      data_long$status_long[i] <- data_long$status[i]
  }
  
  
  # intervals2 <- dummy_cols(as.factor(data_long$interval))
  # colnames(intervals2) <- gsub(".data", "interval", colnames(intervals2))
  # data_long <- data.frame(data_long, intervals2[, seq(2, max(n.times) + 1, by = 1)])
  
  
  events <- dummy_cols(as.factor(data_long$status_long))
  colnames(events) <- gsub(".data", "event", colnames(events))
  data_long <- data.frame(data_long, events[, seq(2, ncol(events), by = 1)])
  
  # interval scaled
  data_long$interval_scaled <- scale(data_long$interval)
  
  data_long <- data_long[, c("id", "time", "status", "age", "hgb", "clinstg",
                             "ch",  "interval", "interval_scaled", "survival",
                             "status_long", "event_0", "event_1", "event_2" )]
  return(data_long)
  
}



metrics_cause1 <- function(risk_matrix, data) {
  
  f_nn <- Hist(time, status) ~ 1
  # we calculate the Brier score utilizing the pec package
  # we subtract 1 day at 8 years to avoid zero censoring prob weight at this time  
  bsc <- riskRegression:::Score(object = list("nnet" = risk_matrix),
                                formula = f_nn,
                                data = data,
                                metrics = c("Brier"),
                                cause = 1,
                                times = c(0:11, 11.999),
                                null.model = FALSE,
                                conservative = TRUE, # speed up computation
                                conf.int = FALSE,
                                split.method = "none")
  
  auc <- riskRegression:::Score(object = list("nnet" = risk_matrix),
                                formula = f_nn,
                                data = data,
                                metrics = c("AUC"),
                                cause = 1, 
                                times = c(0:11, 11.999),
                                null.model = FALSE,
                                conservative = TRUE, # speed up computation
                                conf.int = FALSE,
                                split.method = "none")
  auc$AUC$score[, 3][1] <- 1 # assign 1 if NaNs
  

  return(list(Time = seq(0, 12, length.out = 13), 
              Brier = as.numeric(unlist(bsc$Brier$score[, 3])),
              AUC = as.numeric(unlist(auc$AUC$score[, 3]))))
}


metrics_cause1b <- function(risk_matrix, data) {
  
  f_nn <- Hist(time, status) ~ 1
  # we calculate the Brier score utilizing the pec package
  # we subtract 1 day at 8 years to avoid zero censoring prob weight at this time  
  bsc <- riskRegression:::Score(object = list("nnet" = risk_matrix),
                                formula = f_nn,
                                data = data,
                                metrics = c("Brier"),
                                cause = 1,
                                times = c(0:19, 19.999),
                                null.model = FALSE,
                                conservative = TRUE, # speed up computation
                                conf.int = FALSE,
                                split.method = "none")
  
  auc <- riskRegression:::Score(object = list("nnet" = risk_matrix),
                                formula = f_nn,
                                data = data,
                                metrics = c("AUC"),
                                cause = 1, 
                                times = c(0:19, 19.999),
                                null.model = FALSE,
                                conservative = TRUE, # speed up computation
                                conf.int = FALSE,
                                split.method = "none")
  auc$AUC$score[, 3][1] <- 1 # assign 1 if NaNs
  
  
  return(list(Time = seq(0, 20, length.out = 21), 
              Brier = as.numeric(unlist(bsc$Brier$score[, 3])),
              AUC = as.numeric(unlist(auc$AUC$score[, 3]))))
}



metrics_cause2 <- function(risk_matrix, data) {
  
  f_nn <- Hist(time, status) ~ 1
  # we calculate the Brier score utilizing the pec package
  # we subtract 1 day at 8 years to avoid zero censoring prob weight at this time  
  bsc <- riskRegression:::Score(object = list("nnet" = risk_matrix),
                                formula = f_nn,
                                data = data,
                                metrics = c("Brier"),
                                cause = 2,
                                times = c(0:11, 11.999),
                                null.model = FALSE,
                                conservative = TRUE, # speed up computation
                                conf.int = FALSE,
                                split.method = "none")
  
  auc <- riskRegression:::Score(object = list("nnet" = risk_matrix),
                                formula = f_nn,
                                data = data,
                                metrics = c("AUC"),
                                cause = 2, 
                                times = c(0:11, 11.999),
                                null.model = FALSE,
                                conservative = TRUE, # speed up computation
                                conf.int = FALSE,
                                split.method = "none")
  auc$AUC$score[, 3][1] <- 1 # assign 1 if NaNs
  
  
  return(list(Time = seq(0, 12, length.out = 13), 
              Brier = as.numeric(unlist(bsc$Brier$score[, 3])),
              AUC = as.numeric(unlist(auc$AUC$score[, 3]))))
}



metrics_cause2b <- function(risk_matrix, data) {
  
  f_nn <- Hist(time, status) ~ 1
  # we calculate the Brier score utilizing the pec package
  # we subtract 1 day at 8 years to avoid zero censoring prob weight at this time  
  bsc <- riskRegression:::Score(object = list("nnet" = risk_matrix),
                                formula = f_nn,
                                data = data,
                                metrics = c("Brier"),
                                cause = 2,
                                times = c(0:19, 19.999),
                                null.model = FALSE,
                                conservative = TRUE, # speed up computation
                                conf.int = FALSE,
                                split.method = "none")
  
  auc <- riskRegression:::Score(object = list("nnet" = risk_matrix),
                                formula = f_nn,
                                data = data,
                                metrics = c("AUC"),
                                cause = 2, 
                                times = c(0:19, 19.999),
                                null.model = FALSE,
                                conservative = TRUE, # speed up computation
                                conf.int = FALSE,
                                split.method = "none")
  auc$AUC$score[, 3][1] <- 1 # assign 1 if NaNs
  
  
  return(list(Time = seq(0, 20, length.out = 21), 
              Brier = as.numeric(unlist(bsc$Brier$score[, 3])),
              AUC = as.numeric(unlist(auc$AUC$score[, 3]))))
}


# calibration as the MSE of groups
calibration_mse <- function(cumprob_vec, data, time, cutpoints = 4, cause) { 
  
  
  if (var(cumprob_vec, na.rm = TRUE) != 0) { # run if not all probabilities are equal
    
    cuts <- unique(quantile(cumprob_vec, seq(0, 1, length = cutpoints + 1), na.rm = TRUE))
    
    if ((length(cuts) - 1) == cutpoints) { # if cutpoints groups do exist
    
    data$groups <- as.factor(as.numeric(cut(x = cumprob_vec, breaks = as.vector(cuts),
                                            include.lowest = TRUE)))
    
    # average cumulative incidence of event c
    average_cumprobs <- vector(mode = "numeric", length = length(cuts) - 1)
    for (i in 1:(length(cuts) - 1)) {
      average_cumprobs[i] <- mean(cumprob_vec[which(as.numeric(data$groups) == i)], na.rm = TRUE)
    }
    
    # compare with observed cumulative incidence of event of type cause
    observed_cumprobs_all <- summary(Cuminc("time", "status", group = "groups", data = data),
                                     times = time, extend = TRUE)
    
    observed_cumprobs <-  observed_cumprobs_all$pstate[, 1 + cause]
    
    
    mse <- sum((observed_cumprobs - average_cumprobs)^2, na.rm = TRUE) / length(average_cumprobs)
    
    } else { # else if they are equal set to NA
      
      mse <- NA
      
    } 
    
  } else { # else if they are equal set to NA
    
    mse <- NA
    
    } 
  
  # return the mean squared errors calculated
  return(list(mse_groups = mse))

}



# calculate the predictive performance measures for nnet

measures_nnet_melan <- function(trained_model, datashort, datalong) {
  
  test_x <- datalong[, c(4:13, 15)]
  dimnames(test_x) <- NULL
  datalong <- as.data.frame(datalong)
  real_times <- datashort$time
  real_status <- datashort$status
  
  df1 <- data.frame(predict(trained_model, test_x, type = "raw"))
  colnames(df1) <- c("prob_0", "prob_1", "prob_2")
  
  df1$id <- as.vector(datalong$id) # ids of the patients
  df1$interval <- as.vector(datalong$interval)
  df1$survival <- datalong$survival
  groups <- split(df1, f = df1$id) # split to lists per id
  
  # discrete cause-specific cumulative incidence: cause 1
  risks1_probs <-  lapply(groups, function(x) {
    x <- cumsum(cumprod(1 - (x$prob_1 + x$prob_2))*x$prob_1)})
  # cumulative incidence of an event of cause 1 until time t 
  # in the rows the values should be increasing
  risks1_mat <- cbind(0, do.call("rbind", risks1_probs))
  dimnames(risks1_mat) <- NULL
  
  # discrete cause-specific cumulative incidence: cause 2
  risks2_probs <-  lapply(groups, function(x) {
    x <- cumsum(cumprod(1 - (x$prob_1 + x$prob_2))*x$prob_2)})
  risks2_mat <- cbind(0, do.call("rbind", risks2_probs))
  dimnames(risks2_mat) <- NULL
  
  df2 <- data.frame(time = real_times,
                    status = real_status)
  
  # for cause-specific hazards 1
  metrics_obj1 <- metrics_cause1(risk_matrix = risks1_mat, data = df2)
  brier_set1 <- metrics_obj1$Brier
  auc_set1 <- metrics_obj1$AUC
  mse_set1_time2 <- calibration_mse(cumprob_vec = risks1_mat[, 3], data = df2,
                                    time = 2, cutpoints = 4, cause = 1)$mse_groups
  mse_set1_time5 <- calibration_mse(cumprob_vec = risks1_mat[, 6], data = df2,
                              time = 5, cutpoints = 4, cause = 1)$mse_groups
  mse_set1_time10 <- calibration_mse(cumprob_vec = risks1_mat[, 11], data = df2,
                                    time = 10, cutpoints = 4, cause = 1)$mse_groups
  
  
  
  # for cause-specific hazards 2
  metrics_obj2 <- metrics_cause2(risk_matrix = risks2_mat, data = df2)
  brier_set2 <- metrics_obj2$Brier
  auc_set2 <- metrics_obj2$AUC
  mse_set2_time2 <- calibration_mse(cumprob_vec = risks2_mat[, 3], data = df2,
                                    time = 2, cutpoints = 4, cause = 2)$mse_groups
  mse_set2_time5 <- calibration_mse(cumprob_vec = risks2_mat[, 6], data = df2,
                                    time = 5, cutpoints = 4, cause = 2)$mse_groups
  mse_set2_time10 <- calibration_mse(cumprob_vec = risks2_mat[, 11], data = df2,
                                     time = 10, cutpoints = 4, cause = 2)$mse_groups
  
  return(list(Risks1_mat = risks1_mat,
              Risks2_mat = risks2_mat,
              Time = metrics_obj1$Time,
              Brier_cause1 = brier_set1,
              AUC_cause1 = auc_set1,
              MSE2_cause1 = mse_set1_time2,
              MSE5_cause1 = mse_set1_time5,
              MSE10_cause1 = mse_set1_time10,
              Brier_cause2 = brier_set2,
              AUC_cause2 = auc_set2,
              MSE2_cause2 = mse_set2_time2,
              MSE5_cause2 = mse_set2_time5,
              MSE10_cause2 = mse_set2_time10))
  
}



measures_keras_melan <- function(trained_model, datashort, datalong) {
  
  test_x <- datalong[, c(4:13, 15)]
  dimnames(test_x) <- NULL
  datalong <- as.data.frame(datalong)
  real_times <- datashort$time
  real_status <- datashort$status
  
  df1 <- data.frame(predict(trained_model, test_x, batch_size = 32))
  colnames(df1) <- c("prob_0", "prob_1", "prob_2")
  
  df1$id <- as.vector(datalong$id) # ids of the patients
  df1$interval <- as.vector(datalong$interval)
  df1$survival <- datalong$survival
  groups <- split(df1, f = df1$id) # split to lists per id
  
  # discrete cause-specific cumulative incidence: cause 1
  risks1_probs <-  lapply(groups, function(x) {
    x <- cumsum(cumprod(1 - (x$prob_1 + x$prob_2))*x$prob_1)})
  # cumulative incidence of an event of cause 1 until time t 
  # in the rows the values should be increasing
  risks1_mat <- cbind(0, do.call("rbind", risks1_probs))
  dimnames(risks1_mat) <- NULL
  
  # discrete cause-specific cumulative incidence: cause 2
  risks2_probs <-  lapply(groups, function(x) {
    x <- cumsum(cumprod(1 - (x$prob_1 + x$prob_2))*x$prob_2)})
  risks2_mat <- cbind(0, do.call("rbind", risks2_probs))
  dimnames(risks2_mat) <- NULL
  
  df2 <- data.frame(time = real_times,
                    status = real_status)
  
  # for cause-specific hazards 1
  metrics_obj1 <- metrics_cause1(risk_matrix = risks1_mat, data = df2)
  brier_set1 <- metrics_obj1$Brier
  auc_set1 <- metrics_obj1$AUC
  mse_set1_time2 <- calibration_mse(cumprob_vec = risks1_mat[, 3], data = df2,
                                    time = 2, cutpoints = 4, cause = 1)$mse_groups
  mse_set1_time5 <- calibration_mse(cumprob_vec = risks1_mat[, 6], data = df2,
                                    time = 5, cutpoints = 4, cause = 1)$mse_groups
  mse_set1_time10 <- calibration_mse(cumprob_vec = risks1_mat[, 11], data = df2,
                                     time = 10, cutpoints = 4, cause = 1)$mse_groups
  
  
  # for cause-specific hazards 2
  metrics_obj2 <- metrics_cause2(risk_matrix = risks2_mat, data = df2)
  brier_set2 <- metrics_obj2$Brier
  auc_set2 <- metrics_obj2$AUC
  mse_set2_time2 <- calibration_mse(cumprob_vec = risks2_mat[, 3], data = df2,
                                    time = 2, cutpoints = 4, cause = 2)$mse_groups
  mse_set2_time5 <- calibration_mse(cumprob_vec = risks2_mat[, 6], data = df2,
                                    time = 5, cutpoints = 4, cause = 2)$mse_groups
  mse_set2_time10 <- calibration_mse(cumprob_vec = risks2_mat[, 11], data = df2,
                                     time = 10, cutpoints = 4, cause = 2)$mse_groups
  
  return(list(Risks1_mat = risks1_mat,
              Risks2_mat = risks2_mat,
              Time = metrics_obj1$Time,
              Brier_cause1 = brier_set1,
              AUC_cause1 = auc_set1,
              MSE2_cause1 = mse_set1_time2,
              MSE5_cause1 = mse_set1_time5,
              MSE10_cause1 = mse_set1_time10,
              Brier_cause2 = brier_set2,
              AUC_cause2 = auc_set2,
              MSE2_cause2 = mse_set2_time2,
              MSE5_cause2 = mse_set2_time5,
              MSE10_cause2 = mse_set2_time10))
  
}


measures_melan <- function(risk_mat1, risk_mat2, datashort) {
 
  # for cause-specific hazards 1
  metrics_obj1 <- metrics_cause1(risk_matrix = risk_mat1, data = datashort)
  brier_set1 <- metrics_obj1$Brier
  auc_set1 <- metrics_obj1$AUC
  mse_set1_time2 <- calibration_mse(cumprob_vec = risk_mat1[, 3], data = datashort,
                                    time = 2, cutpoints = 4, cause = 1)$mse_groups
  mse_set1_time5 <- calibration_mse(cumprob_vec = risk_mat1[, 6], data = datashort,
                                    time = 5, cutpoints = 4, cause = 1)$mse_groups
  mse_set1_time10 <- calibration_mse(cumprob_vec = risk_mat1[, 11], data = datashort,
                                     time = 10, cutpoints = 4, cause = 1)$mse_groups
  
  
  # for cause-specific hazards 2
  metrics_obj2 <- metrics_cause2(risk_matrix = risk_mat2, data = datashort)
  brier_set2 <- metrics_obj2$Brier
  auc_set2 <- metrics_obj2$AUC
  mse_set2_time2 <- calibration_mse(cumprob_vec = risk_mat2[, 3], data = datashort,
                                    time = 2, cutpoints = 4, cause = 2)$mse_groups
  mse_set2_time5 <- calibration_mse(cumprob_vec = risk_mat2[, 6], data = datashort,
                                    time = 5, cutpoints = 4, cause = 2)$mse_groups
  mse_set2_time10 <- calibration_mse(cumprob_vec = risk_mat2[, 11], data = datashort,
                                     time = 10, cutpoints = 4, cause = 2)$mse_groups
  
  return(list(Risks1_mat = risk_mat1,
              Risks2_mat = risk_mat2,
              Time = metrics_obj1$Time,
              Brier_cause1 = brier_set1,
              AUC_cause1 = auc_set1,
              MSE2_cause1 = mse_set1_time2,
              MSE5_cause1 = mse_set1_time5,
              MSE10_cause1 = mse_set1_time10,
              Brier_cause2 = brier_set2,
              AUC_cause2 = auc_set2,
              MSE2_cause2 = mse_set2_time2,
              MSE5_cause2 = mse_set2_time5,
              MSE10_cause2 = mse_set2_time10))
   
}  



# calculate the predictive performance measures for nnet
measures_nnet_follic <- function(trained_model, datashort, datalong) {
  
  test_x <- datalong[, c(4:7, 9)]
  dimnames(test_x) <- NULL
  datalong <- as.data.frame(datalong)
  real_times <- datashort$time
  real_status <- datashort$status
  
  df1 <- data.frame(predict(trained_model, test_x, type = "raw"))
  colnames(df1) <- c("prob_0", "prob_1", "prob_2")
  
  df1$id <- as.vector(datalong$id) # ids of the patients
  df1$interval <- as.vector(datalong$interval)
  df1$survival <- datalong$survival
  groups <- split(df1, f = df1$id) # split to lists per id
  
  # discrete cause-specific cumulative incidence: cause 1
  risks1_probs <-  lapply(groups, function(x) {
    x <- cumsum(cumprod(1 - (x$prob_1 + x$prob_2))*x$prob_1)})
  # cumulative incidence of an event of cause 1 until time t 
  # in the rows the values should be increasing
  risks1_mat <- cbind(0, do.call("rbind", risks1_probs))
  dimnames(risks1_mat) <- NULL
  
  # discrete cause-specific cumulative incidence: cause 2
  risks2_probs <-  lapply(groups, function(x) {
    x <- cumsum(cumprod(1 - (x$prob_1 + x$prob_2))*x$prob_2)})
  risks2_mat <- cbind(0, do.call("rbind", risks2_probs))
  dimnames(risks2_mat) <- NULL
  
  df2 <- data.frame(time = real_times,
                    status = real_status)
  
  # for cause-specific hazards 1
  metrics_obj1 <- metrics_cause1b(risk_matrix = risks1_mat, data = df2)
  brier_set1 <- metrics_obj1$Brier
  auc_set1 <- metrics_obj1$AUC
  mse_set1_time5 <- calibration_mse(cumprob_vec = risks1_mat[, 6], data = df2,
                                    time = 5, cutpoints = 4, cause = 1)$mse_groups
  mse_set1_time10 <- calibration_mse(cumprob_vec = risks1_mat[, 11], data = df2,
                                    time = 10, cutpoints = 4, cause = 1)$mse_groups
  mse_set1_time15 <- calibration_mse(cumprob_vec = risks1_mat[, 16], data = df2,
                                     time = 15, cutpoints = 4, cause = 1)$mse_groups
  
  
  # for cause-specific hazards 2
  metrics_obj2 <- metrics_cause2b(risk_matrix = risks2_mat, data = df2)
  brier_set2 <- metrics_obj2$Brier
  auc_set2 <- metrics_obj2$AUC
  mse_set2_time5 <- calibration_mse(cumprob_vec = risks2_mat[, 6], data = df2,
                                    time = 5, cutpoints = 4, cause = 2)$mse_groups
  mse_set2_time10 <- calibration_mse(cumprob_vec = risks2_mat[, 11], data = df2,
                                    time = 10, cutpoints = 4, cause = 2)$mse_groups
  mse_set2_time15 <- calibration_mse(cumprob_vec = risks2_mat[, 16], data = df2,
                                     time = 15, cutpoints = 4, cause = 2)$mse_groups
  
  return(list(Risks1_mat = risks1_mat,
              Risks2_mat = risks2_mat,
              Time = metrics_obj1$Time,
              Brier_cause1 = brier_set1,
              AUC_cause1 = auc_set1,
              MSE5_cause1 = mse_set1_time5,
              MSE10_cause1 = mse_set1_time10,
              MSE15_cause1 = mse_set1_time15,
              Brier_cause2 = brier_set2,
              AUC_cause2 = auc_set2,
              MSE5_cause2 = mse_set2_time5,
              MSE10_cause2 = mse_set2_time10,
              MSE15_cause2 = mse_set2_time15))
  
}


measures_keras_follic <- function(trained_model, datashort, datalong) {
  
  test_x <- datalong[, c(4:7, 9)]
  dimnames(test_x) <- NULL
  datalong <- as.data.frame(datalong)
  real_times <- datashort$time
  real_status <- datashort$status
  
  df1 <- data.frame(predict(trained_model, test_x, batch_size = 32))
  colnames(df1) <- c("prob_0", "prob_1", "prob_2")
  
  df1$id <- as.vector(datalong$id) # ids of the patients
  df1$interval <- as.vector(datalong$interval)
  df1$survival <- datalong$survival
  groups <- split(df1, f = df1$id) # split to lists per id
  
  
  # discrete cause-specific cumulative incidence: cause 1
  risks1_probs <-  lapply(groups, function(x) {
    x <- cumsum(cumprod(1 - (x$prob_1 + x$prob_2))*x$prob_1)})
  # cumulative incidence of an event of cause 1 until time t 
  # in the rows the values should be increasing
  risks1_mat <- cbind(0, do.call("rbind", risks1_probs))
  dimnames(risks1_mat) <- NULL
  
  # discrete cause-specific cumulative incidence: cause 2
  risks2_probs <-  lapply(groups, function(x) {
    x <- cumsum(cumprod(1 - (x$prob_1 + x$prob_2))*x$prob_2)})
  risks2_mat <- cbind(0, do.call("rbind", risks2_probs))
  dimnames(risks2_mat) <- NULL
  
  df2 <- data.frame(time = real_times,
                    status = real_status)
  
  # for cause-specific hazards 1
  metrics_obj1 <- metrics_cause1b(risk_matrix = risks1_mat, data = df2)
  brier_set1 <- metrics_obj1$Brier
  auc_set1 <- metrics_obj1$AUC
  mse_set1_time5 <- calibration_mse(cumprob_vec = risks1_mat[, 6], data = df2,
                                     time = 5, cutpoints = 4, cause = 1)$mse_groups
  mse_set1_time10 <- calibration_mse(cumprob_vec = risks1_mat[, 11], data = df2,
                                     time = 10, cutpoints = 4, cause = 1)$mse_groups
  mse_set1_time15 <- calibration_mse(cumprob_vec = risks1_mat[, 16], data = df2,
                                     time = 15, cutpoints = 4, cause = 1)$mse_groups
  
  
  # for cause-specific hazards 2
  metrics_obj2 <- metrics_cause2b(risk_matrix = risks2_mat, data = df2)
  brier_set2 <- metrics_obj2$Brier
  auc_set2 <- metrics_obj2$AUC
  mse_set2_time5 <- calibration_mse(cumprob_vec = risks2_mat[, 6], data = df2,
                                    time = 5, cutpoints = 4, cause = 2)$mse_groups
  mse_set2_time10 <- calibration_mse(cumprob_vec = risks2_mat[, 11], data = df2,
                                     time = 10, cutpoints = 4, cause = 2)$mse_groups
  mse_set2_time15 <- calibration_mse(cumprob_vec = risks2_mat[, 16], data = df2,
                                     time = 15, cutpoints = 4, cause = 2)$mse_groups
  
  
  return(list(Risks1_mat = risks1_mat,
              Risks2_mat = risks2_mat,
              Time = metrics_obj1$Time,
              Brier_cause1 = brier_set1,
              AUC_cause1 = auc_set1,
              MSE5_cause1 = mse_set1_time5,
              MSE10_cause1 = mse_set1_time10,
              MSE15_cause1 = mse_set1_time15,
              Brier_cause2 = brier_set2,
              AUC_cause2 = auc_set2,
              MSE5_cause2 = mse_set2_time5,
              MSE10_cause2 = mse_set2_time10,
              MSE15_cause2 = mse_set2_time15))
  
}


measures_follic <- function(risk_mat1, risk_mat2, datashort) {
  
  # for cause-specific hazards 1
  metrics_obj1 <- metrics_cause1b(risk_matrix = risk_mat1, data = datashort)
  brier_set1 <- metrics_obj1$Brier
  auc_set1 <- metrics_obj1$AUC
  mse_set1_time5 <- calibration_mse(cumprob_vec = risk_mat1[, 6], data = datashort,
                                    time = 5, cutpoints = 4, cause = 1)$mse_groups
  mse_set1_time10 <- calibration_mse(cumprob_vec = risk_mat1[, 11], data = datashort,
                                     time = 10, cutpoints = 4, cause = 1)$mse_groups
  mse_set1_time15 <- calibration_mse(cumprob_vec = risk_mat1[, 16], data = datashort,
                                     time = 15, cutpoints = 4, cause = 1)$mse_groups
  
  
  # for cause-specific hazards 2
  metrics_obj2 <- metrics_cause2b(risk_matrix = risk_mat2, data = datashort)
  brier_set2 <- metrics_obj2$Brier
  auc_set2 <- metrics_obj2$AUC
  mse_set2_time5 <- calibration_mse(cumprob_vec = risk_mat2[, 6], data = datashort,
                                    time = 5, cutpoints = 4, cause = 2)$mse_groups
  mse_set2_time10 <- calibration_mse(cumprob_vec = risk_mat2[, 11], data = datashort,
                                     time = 10, cutpoints = 4, cause = 2)$mse_groups
  mse_set2_time15 <- calibration_mse(cumprob_vec = risk_mat2[, 16], data = datashort,
                                     time = 15, cutpoints = 4, cause = 2)$mse_groups
  
  return(list(Risks1_mat = risk_mat1,
              Risks2_mat = risk_mat2,
              Time = metrics_obj1$Time,
              Brier_cause1 = brier_set1,
              AUC_cause1 = auc_set1,
              MSE5_cause1 = mse_set1_time5,
              MSE10_cause1 = mse_set1_time10,
              MSE15_cause1 = mse_set1_time15,
              Brier_cause2 = brier_set2,
              AUC_cause2 = auc_set2,
              MSE5_cause2 = mse_set2_time5,
              MSE10_cause2 = mse_set2_time10,
              MSE15_cause2 = mse_set2_time15))
  
}  





