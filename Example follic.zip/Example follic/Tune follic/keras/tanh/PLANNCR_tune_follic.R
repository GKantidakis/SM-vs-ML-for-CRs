
# tuning follic
# with bootstrap, search for hyperparameters afresh for each loop
# supervised learning steps inside the loop
# B = 100
# original data  ---> N = 500 develop, N = OOB validate

library(riskRegression)
library(prodlim)
library(ggplot2)
library(survival)
library(data.table)
library(nnet)
library(keras)
library(tictoc)
library(randomForestSRC)
source("functions_nncr.R")

# dataset 2
data("follic") # n = 541, p = 4
# define ids
follic$id <- 1:nrow(follic)
follic$clinstg <- as.factor(follic$clinstg)

# apply administrative censoring at 20 years
follic$status <- follic$status*(follic$time <= 20)
follic$time <- pmin(follic$time, 20)
# variables: age, hgb, clinstg (1 or 2), ch (N or Y)


#############################
# bootstrapping
#############################

set.seed(12345)
n <- nrow(follic)
B <- 100

# getting the bootstrap samples without loops
# each column is a bootstrap re-sample
boot_samples <- matrix(sample(follic$id, size = n*B, replace = TRUE),
                       nrow = n, ncol = B)

# create objects to store the statistics
# create a loop to calculate the statistics

# 144 combis
node_size <- seq(2, 5, by = 1) # grid of node sizes
dropout_rate <- c(0.1, 0.2, 0.4)
lr <- c(0.1, 0.2, 0.4)
momentum <- c(0.8, 0.9)
class_weights <- c(1, 1.25)
combis <- expand.grid(node_size, dropout_rate, lr, momentum, class_weights)

# initialize objects
mat_brier <-  matrix(0, nrow = B, ncol = nrow(combis))
mat_auc <- matrix(0, nrow = B, ncol = nrow(combis))
mat_calib <- matrix(0, nrow = B, ncol = nrow(combis))


# run the bootstrap training
tic("Running the bootstrap training")


for (i in 1:B) {
  
  cat("Started iteration i = ", i, "\n")
  # use the proper bootstrap column
  indices <- boot_samples[, i]
  
  follic2 <- follic[indices, ]
  follic2$id <- 1:nrow(follic2)
  
  # sample randomly 3/4 of data as train and 1/4 as test data per bootstrap sample
  set.seed(12345)
  vec <- sample(x = follic2$id, size = round((3/4)*nrow(follic2))) 
  follic2_train <- follic2[follic2$id %in% vec, ]
  follic2_test <- follic2[!(follic2$id %in% vec), ]
  
  # scale data
  follic2_train$age <- scale(follic2_train$age)
  follic2_train$hgb <- scale(follic2_train$hgb)
  follic2_test$age <- scale(follic2_test$age)
  follic2_test$hgb <- scale(follic2_test$hgb)
  
  train_long_follic <- train_creator_follic(data = follic2_train)
  # categorical variables to numerical (reference level redundant)
  train_long_follic <- model.matrix(~., train_long_follic)[, -1] 
  
  train_x_follic <- train_long_follic[, c(4:7, 9)] # p = 4 variables + time interval
  dimnames(train_x_follic) <- NULL # the object must have empty dimnames
  train_y_follic <- train_long_follic[, (ncol(train_long_follic) - 2):ncol(train_long_follic)]
  dimnames(train_y_follic) <- NULL
  
  test_long_follic <- test_creator_follic(data = follic2_test)
  # categorical variables to numerical (reference level redundant)
  test_long_follic <- model.matrix(~., test_long_follic)[, -1]
  
  test_x_follic <- test_long_follic[, c(4:7, 9)] # p = 4 variables + time interval
  dimnames(test_x_follic) <- NULL # the object must have empty dimnames
  test_y_follic <- test_long_follic[, (ncol(train_long_follic) - 2):ncol(train_long_follic)]
  dimnames(test_y_follic) <- NULL
  
  
  for (j in 1:nrow(combis)) { 
    
    cat("Testing combination number:", j, "of repeat", i, "out of", B, "\n")
    cat("calculating for node size:", combis[j, 1], ", dropout rate:", combis[j, 2], "\n",
        "and learning rate", combis[j, 3], "and momentum", combis[j, 4],
        "and weak class weight", combis[j, 5], "...", "\n")

    
  # start building the model in keras
  
  # set global default to never show metrics
  options(keras.view_metrics = FALSE)
  k_clear_session() # to avoid clutter from old models / layers in cross validation
  tensorflow::tf$random$set_seed(12345) # for update to TensorFlow 2.0
  # model with one hidden layer
  
  # Initialize a sequential model
  fit_keras1 <- keras_model_sequential() 
  
  # Add layers to the model
  fit_keras1 %>% 
    layer_dense(units = combis[j, 1], activation = 'tanh',
                input_shape = ncol(train_x_follic)) %>% 
    layer_dropout(rate = combis[j, 2]) %>%
    layer_dense(units = 3, activation = 'softmax')
  
  # Compile the model
  fit_keras1 %>% compile(
    loss = 'categorical_crossentropy', # for multi-class classification problem
    optimizer = optimizer_sgd(learning_rate = combis[j, 3], momentum = combis[j, 4])
    #, metrics = c("accuracy")
  )
  early_stopping <- callback_early_stopping(monitor = 'val_loss', patience = 3)
  
  result_keras <- fit_keras1 %>% fit(
    train_x_follic,
    train_y_follic,
    epochs = 50,
    batch_size = 32,
    validation_data = list(test_x_follic, test_y_follic),
    class_weight = list("0" = 1, "1" = combis[j, 5], "2" = combis[j, 5]),
    callbacks = c(early_stopping),
    verbose = 0 # don't display progress bar
  )
  
  
  results2 <- measures_keras_follic(trained_model = fit_keras1,
                                  datashort = follic2_test, 
                                  datalong = test_long_follic)
  
  mat_brier[i, j] <- results2$Brier_cause1[6]
  mat_auc[i, j] <- results2$AUC_cause1[6]
  mat_calib[i, j] <- results2$MSE5_cause1
  
  cat("The Brier Score at 5 years is:", round(results2$Brier_cause1[6], 3),
      "and the AUC is:", round(results2$AUC_cause1[6], 3), "\n")
  
  }
  
  
}

time_list <- toc()

cat((time_list$toc - time_list$tic) / 3600, "hours elapsed", "\n") 
# 24.55598 hours elapsed

df_tanh_ovr <- as.data.frame(cbind(node_size = combis[, 1],
                                      dropout_rate = combis[, 2],
                                      lr = combis[, 3],
                                      momentum = combis[, 4],
                                      weak_class = combis[, 5],
                                      brier5 = colMeans(mat_brier),
                                      auc5 = colMeans(mat_auc),
                                      calib5 = colMeans(mat_calib,
                                                         na.rm = TRUE))) 

save(df_tanh_ovr, file = "results_keras_follic.RData")

# best brier
ind <- head(order(df_tanh_ovr$brier5, decreasing = FALSE), 3)
df_tanh_ovr[ind, ]

# best auc
ind2 <- head(order(df_tanh_ovr$auc5, decreasing = TRUE), 3)
df_tanh_ovr[ind2, ]

# best calibration
ind3 <- head(order(df_tanh_ovr$calib5, decreasing = FALSE), 3)
df_tanh_ovr[ind3, ]






